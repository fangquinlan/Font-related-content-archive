"""Constrained, component-aware dictionary mark fitting. No source rewriting.

Normal lower marks retain their vertical lanes. Pair order, holam side, base
association, and inside-letter dagesh are constraints, rather than penalties.
Editorial multi-vowel notation is retained visibly but is not certified as
ordinary Hebrew orthography. Controls are fitted through actual attachment
propagation after compilation.
"""
from collections import defaultdict
from concurrent.futures import ProcessPoolExecutor, as_completed
from io import StringIO
from pathlib import Path
import copy, hashlib, json, math, time
from fontTools.feaLib.builder import addOpenTypeFeatures
from fontTools.otlLib.builder import buildSinglePosSubtable, buildLookup, buildCoverage, buildValue
from fontTools.ttLib import TTFont
from fontTools.ttLib.tables import otTables
from fontTools.ttLib.tables.DefaultTable import DefaultTable
from audit_maagarim_sbl import ComponentShaper, ROOT, dump, signature
from audit_dictionaries_v6b import PARENT, REPORT, layout_issues, code, source_issues, center, mark_owners, POSTPOSITIVE, stress_helper
from report_maagarim_sbl import ComponentRaster
from validate_sbl_maagarim_v6a import near_boxes

DEST=ROOT/'output/sbl-v6b/SBL_BLit-v6b.ttf'
SIZES=[14,18,24,32,48,72]
PHASES=[0,.25,.5,.75]
MARGIN=40

def shifted(g,dx=0,dy=0):return dict(g,x=g['x']+dx,y=g['y']+dy)
def cx(g):return center(g)[0]
def cy(g):return center(g)[1]

def role_edges(parts,text):
    """Indices in expanded components, with the left item first."""
    edges=set();owners=mark_owners(parts)
    for i,a in enumerate(parts):
        ac=code(a)
        if not a['box']:continue
        for j,b in enumerate(parts):
            bc=code(b)
            if i==j or owners[i]!=owners[j] or not b['box']:continue
            end=min([p['cl'] for p in parts if p['cl']>a['cl']]+[len(text)])
            cluster=text[a['cl']:end]
            if '\u034f' in cluster:continue
            if ac in (0x05b9,0x05ba) and bc and 0x0591<=bc<=0x05ae and cy(b)>700:
                if not stress_helper(b,text):edges.add((j,i) if bc in POSTPOSITIVE else (i,j))
            if ac in (0x05b9,0x05ba) and bc==0x05c2 and any(code(p)==0x05e9 and not p['mark'] and owners[k]==owners[i] for k,p in enumerate(parts)):edges.add((i,j))
            if ac and 0x05b0<=ac<=0x05b8 or ac in (0x05bb,0x05c7):
                if cy(a)<0 and bc and 0x0591<=bc<=0x05ae and cy(b)<0:
                    edges.add((i,j) if bc in (0x059a,0x05ad) else (j,i))
                if cy(a)<0 and bc==0x05bd:
                    end=min([p['cl'] for p in parts if p['cl']>a['cl']]+[len(text)])
                    cluster=text[a['cl']:end]
                    if not any(c in cluster for c in '\u034f\u200d\u200c') and ac not in (0x05b1,0x05b2,0x05b3):edges.add((j,i))
    # Preserve the encoded/readable order of multiple lower vowels and meteg.
    for cl in {p['cl'] for p in parts}:
        lower=[i for i,p in enumerate(parts) if p['cl']==cl and p['mark'] and p['box'] and cy(p)<0 and code(p)!=0x05bd]
        lower.sort(key=lambda i:(cx(parts[i]),i))
        for i,j in zip(lower,lower[1:]):
            if (j,i) not in edges:edges.add((i,j))
    return sorted(edges)

def solve(s,text,rasters,max_dx=640,only_clusters=None,initial=None,include_neighbors=False,extra_pairs=None,locked_clusters=None,periodic_x=None,annotation_layers=None,first_feasible=False):
    started=time.monotonic()
    def near(a,b,margin):
        return s.near(a,b,margin) or bool(periodic_x and any(s.near(a,shifted(b,dx,0),margin) for dx in (-periodic_x,periodic_x)))
    gs=[shifted(g,*(initial or {}).get(i,(0,0))) for i,g in enumerate(s.shape(text))]
    parts=s.expand(gs);hits=s.mark_collisions(parts)+list(extra_pairs or []);roles=layout_issues(parts,text)
    if only_clusters is not None:
        hits=[h for h in hits if any(parts[h[k]]['cl'] in only_clusters for k in ('i','j'))]
        roles=[h for h in roles if any(parts[h[k]]['cl'] in only_clusters for k in ('i','j'))]
    if not hits and not roles:return {},dict(method='already_clear')
    involved={parts[c[k]]['glyph_index'] for c in hits+roles for k in ('i','j')}
    active={i for i in involved if gs[i]['mark'] and gs[i]['box']}
    if only_clusters is not None:active={i for i in active if gs[i]['cl'] in only_clusters}
    clusters={gs[i]['cl'] for i in active}
    if include_neighbors:
        ordered=sorted({g['cl'] for g in gs if not g['mark'] and g['box']})
        for cl in list(clusters):
            if cl in ordered:
                k=ordered.index(cl);clusters.update(ordered[max(0,k-1):k+2])
    targets=[i for i,g in enumerate(gs) if g['cl'] in clusters and g['cl'] not in (locked_clusters or set()) and g['mark'] and g['box'] and
             (g['name'] not in ('uni05BC','uni05C1','uni05C2') or i in active)]
    if not targets:return None,dict(reason='collision has no separately positionable mark')
    edges=role_edges(parts,text);domains={};frozen=[(j,g) for j,g in enumerate(parts) if g['glyph_index'] not in targets]
    # Each directly positioned glyph is one expanded component.
    pindex={g['glyph_index']:j for j,g in enumerate(parts) if g['glyph_index'] in targets}
    assert all(sum(p['glyph_index']==i for p in parts)==1 for i in targets)
    positions={i:next((g for g in gs if not g['mark'] and g['cl']==gs[i]['cl'] and g['box']),None) for i in targets}
    for i in targets:
        g=gs[i];host=positions[i];gc=code(g);opts=[]
        upper=cy(g)>700 or gc in (0x0308,0x030c,0x0311)
        dys=range(0,801,16) if upper else range(-240,241,16) if gc==0x05bc else (annotation_layers or [0])
        for dx in range(-max_dx,max_dx+1,8):
            # The bar should stay centered. Raise it before displacing it.
            if gc==0x05bf and abs(dx)>128:continue
            for dy in dys:
                a=shifted(g,dx,dy)
                if upper and a['y']+a['box'][3]>2192:continue
                if host:
                    left=host['x']-128;right=host['x']+host['advance']+128
                    left=min(left,cx(g)-32);right=max(right,cx(g)+32)
                    if not left<=cx(a)<=right:continue
                    if gc in (0x05b9,0x05ba) and cx(a)>=cx(host):continue
                    if gc==0x05bc:
                        if not (host['x']+host['box'][0]<a['x']+a['box'][0] and a['x']+a['box'][2]<host['x']+host['box'][2]
                          and host['y']+host['box'][1]<a['y']+a['box'][1] and a['y']+a['box'][3]<host['y']+host['box'][3]):continue
                pi=pindex[i]
                if any((pi,j) in edges and cx(a)>=cx(b) or (j,pi) in edges and cx(b)>=cx(a) for j,b in frozen if b['box']):continue
                if any(near(a,b,MARGIN if dx or dy else 0) for j,b in frozen):continue
                cost=dx*dx+(4 if gc!=0x05bf else 1)*dy*dy+(1024 if dx or dy else 0)
                opts.append((cost,dx,dy,a))
        domains[i]=sorted(opts,key=lambda v:v[:3])
        if not opts:return None,dict(reason='empty_domain',index=i,name=g['name'],targets=targets)
    order=sorted(targets,key=lambda i:len(domains[i]));suffix=[0]*(len(order)+1)
    for k in reversed(range(len(order))):suffix[k]=suffix[k+1]+domains[order[k]][0][0]
    best=None;nodes=0;raster_rejected=0;compat={}
    def okay(i,a,j,b):
        key=(i,a[1],a[2],j,b[1],b[2])
        if key not in compat:
            pi,pj=pindex[i],pindex[j]
            ordered=not ((pi,pj) in edges and cx(a[3])>=cx(b[3]) or (pj,pi) in edges and cx(b[3])>=cx(a[3]))
            compat[key]=ordered and not near(a[3],b[3],MARGIN)
        return compat[key]
    def visit(k,cost,chosen,remaining):
        nonlocal best,nodes,raster_rejected
        if first_feasible and best is not None:return
        nodes+=1
        if nodes%256==0 and (nodes>100000 or time.monotonic()-started>40):
            raise TimeoutError('Bounded search needs a wider cluster or a smaller joint component')
        lower_bound=sum(v[0][0] for v in remaining.values())
        if best and cost+lower_bound>=best[0]:return
        if k==len(order):
            changes={i:(v[1],v[2]) for i,v in chosen.items() if v[1] or v[2]}
            shaped=[shifted(g,*changes.get(i,(0,0))) for i,g in enumerate(gs)]
            pp=s.expand(shaped)
            problems=s.mark_collisions(pp)+layout_issues(pp,text)
            if only_clusters is not None:problems=[h for h in problems if any(pp[h[k]]['glyph_index'] in targets for k in ('i','j'))]
            if problems:return
            pairs=[dict(i=i,j=j) for i,a in enumerate(pp) for j,b in enumerate(pp[i+1:],i+1)
                   if (a['glyph_index'] in changes or b['glyph_index'] in changes or
                       extra_pairs and (a['glyph_index'] in targets or b['glyph_index'] in targets))
                   and (a['mark'] or b['mark']) and (periodic_x or near_boxes(a,b))]
            if any(r.pair_pixels(pp,p,phase) for r in rasters for p in pairs for phase in PHASES):
                raster_rejected+=1;return
            if periodic_x:
                for p in pairs:
                    for dx in (-periodic_x,periodic_x):
                        repeat=list(pp);repeat[p['j']]=shifted(repeat[p['j']],dx,0)
                        if any(r.pair_pixels(repeat,p,phase) for r in rasters for phase in PHASES):
                            raster_rejected+=1;return
            best=cost,changes;return
        i=min(remaining,key=lambda j:len(remaining[j]))
        other_bound=lower_bound-remaining[i][0][0]
        for v in remaining[i]:
            if first_feasible and best is not None:break
            if best and cost+v[0]+other_bound>=best[0]:break
            future={};possible=True
            for j,values in remaining.items():
                if j==i:continue
                kept=[w for w in values if okay(i,v,j,w)]
                if not kept:possible=False;break
                future[j]=kept
            if possible:
                chosen[i]=v;visit(k+1,cost+v[0],chosen,future);del chosen[i]
    timed_out=False
    try:visit(0,0,{},domains)
    except TimeoutError:
        if best is None:raise
        timed_out=True
    return (best[1] if best else None),dict(nodes=nodes,raster_rejected=raster_rejected,
        domains={i:len(v) for i,v in domains.items()},cost=best[0] if best else None,
        vowel_y_locked=not bool(annotation_layers),role_edges=edges,host_association_bounded=True,clearance=MARGIN,
        annotation_layers=annotation_layers,search_time_limited=timed_out,global_optimum_proved=not timed_out and not first_feasible)

def solve_split(s,text,rasters,max_dx=640):
    gs=s.shape(text);pp=s.expand(gs);problems=s.mark_collisions(pp)+layout_issues(pp,text)
    cls=sorted({pp[h[k]]['cl'] for h in problems for k in ('i','j') if gs[pp[h[k]]['glyph_index']]['mark']})
    if len(cls)<2:return solve(s,text,rasters,max_dx)
    best=None;attempts=[]
    for order in [cls,list(reversed(cls))]:
        changes={};steps=[];failed=False
        for cl in order:
            try:delta,details=solve(s,text,rasters,max_dx,only_clusters={cl},initial=changes)
            except TimeoutError as e:delta=None;details=dict(reason=str(e))
            steps.append(dict(cluster=cl,details=details))
            if delta is None:failed=True;break
            for i,(dx,dy) in delta.items():
                ox,oy=changes.get(i,(0,0));changes[i]=(ox+dx,oy+dy)
        final=s.expand([shifted(g,*changes.get(i,(0,0))) for i,g in enumerate(gs)])
        if s.mark_collisions(final) or layout_issues(final,text):failed=True
        attempts.append(dict(order=order,steps=steps,failed=failed))
        cost=sum(dx*dx+4*dy*dy for dx,dy in changes.values())
        if not failed and (best is None or cost<best[0]):best=cost,changes
    return (best[1] if best else None),dict(method='component_order_search',attempts=attempts,cost=best[0] if best else None,
        vowel_y_locked=True,host_association_bounded=True,clearance=MARGIN)

def export(controls,path,base=PARENT,*,report=REPORT,family='SBL Local Optical V6b',
           ps='SBLLocalOpticalV6b-Regular',revision=6.202,
           version_text='Version 6.202; dictionary Hebrew mark repair',unique_id=None):
    actions=defaultdict(set);rules=set()
    for r in controls:
        names=r['names']
        for i in set(r['changes'])|set(r.get('advance_changes',{})):
            dx,dy=r['changes'].get(i,(0,0));da=r.get('advance_changes',{}).get(i,0)
            if dx or dy or da or r.get('guard_zero',False):
                actions[dx,dy,da].add(names[i]);rules.add((tuple(names),i,dx,dy,da))
    ids={xy:f'DictionaryMove{i}' for i,xy in enumerate(sorted(actions))}
    lines=['languagesystem hebr dflt;']
    for (dx,dy,da),name in ids.items():
        lines.append(f"lookup {name} {{ pos [{' '.join(sorted(actions[dx,dy,da]))}] <{dx} {dy} {da} 0>; }} {name};")
    lines+=['lookup DictionaryContexts useExtension {','lookupflag RightToLeft;']
    for names,i,dx,dy,da in sorted(rules,key=lambda r:(-len(r[0]),r)):
        terms=list(reversed(names));terms[len(names)-1-i]+=f"' lookup {ids[dx,dy,da]}"
        lines.append('pos '+' '.join(terms)+';')
    lines+=['} DictionaryContexts;','feature mark { script hebr; language dflt; lookup DictionaryContexts; } mark;']
    fea='\n'.join(lines)+'\n';(report/'dictionary-v6b.fea').write_text(fea,encoding='utf8')
    f=TTFont(base,recalcTimestamp=False);f.setGlyphOrder(f.getGlyphOrder());g=f['GPOS'].table
    offset=len(g.LookupList.Lookup);glyphmap=f.getReverseGlyphMap();lookups=[];action_ids={}
    for dx,dy,da in sorted(actions):
        value=buildValue({k:v for k,v in dict(XPlacement=dx,YPlacement=dy,XAdvance=da).items() if v})
        st=buildSinglePosSubtable({n:value for n in actions[dx,dy,da]},glyphmap)
        action_ids[dx,dy,da]=offset+len(lookups);lookups.append(buildLookup([st],table='GPOS',extension=True))
    # Anchor each invocation at the actual adjusted glyph, with the rest of
    # the word as backtrack/lookahead. One action may affect attachment chains;
    # the response fitter below compensates without changing old lookups.
    contexts=[];grouped=defaultdict(list)
    for names,i,dx,dy,da in sorted(rules,key=lambda r:(-len(r[0]),r)):
        seq=list(reversed(names));pos=len(names)-1-i;st=otTables.ChainPosRule()
        st.Backtrack=list(reversed(seq[:pos]));st.BacktrackGlyphCount=len(st.Backtrack)
        st.Input=[];st.InputGlyphCount=1
        st.LookAhead=seq[pos+1:];st.LookAheadGlyphCount=len(st.LookAhead)
        record=otTables.PosLookupRecord();record.SequenceIndex=0;record.LookupListIndex=action_ids[dx,dy,da]
        st.PosLookupRecord=[record];st.PosCount=1;grouped[seq[pos]].append(st)
    # Format 1 stores literal glyph IDs instead of one coverage table per
    # position. Bucket by the adjusted glyph: disjoint buckets preserve the
    # exact match order while keeping every internal 16-bit offset bounded.
    for name in sorted(grouped,key=glyphmap.get):
        ruleset=otTables.ChainPosRuleSet();ruleset.ChainPosRule=grouped[name];ruleset.ChainPosRuleCount=len(grouped[name])
        st=otTables.ChainContextPos();st.Format=1;st.Coverage=buildCoverage([name],glyphmap)
        st.ChainPosRuleSet=[ruleset];st.ChainPosRuleSetCount=1;contexts.append(st)
    top=[offset+len(lookups)]
    lookups.append(buildLookup(contexts,flags=1,table='GPOS',extension=True))
    g.LookupList.Lookup.extend(lookups);g.LookupList.LookupCount=len(g.LookupList.Lookup)
    hebr=next(r.Script for r in g.ScriptList.ScriptRecord if r.ScriptTag=='hebr')
    ids={i for lang in [hebr.DefaultLangSys]+[x.LangSys for x in hebr.LangSysRecord] if lang for i in lang.FeatureIndex if g.FeatureList.FeatureRecord[i].FeatureTag=='mark'}
    for r in g.ScriptList.ScriptRecord:
        if r.ScriptTag!='hebr':
            for lang in [r.Script.DefaultLangSys]+[x.LangSys for x in r.Script.LangSysRecord]:assert not lang or not ids.intersection(lang.FeatureIndex)
    for i in ids:
        feat=g.FeatureList.FeatureRecord[i].Feature;feat.LookupListIndex+=top;feat.LookupCount=len(feat.LookupListIndex)
    for nid,value in {1:family,2:'Regular',3:unique_id or 'DictionaryMarksV6b;'+ps,4:family+' Regular',5:version_text,6:ps,16:family,17:'Regular'}.items():
        f['name'].removeNames(nameID=nid);f['name'].setName(value,nid,3,1,0x409);f['name'].setName(value,nid,1,0,0)
    f['head'].fontRevision=revision
    for tag in f.reader.keys():
        if tag not in ('GPOS','name','head'):f[tag]=DefaultTable(tag);f[tag].data=f.reader[tag]
    path.parent.mkdir(parents=True,exist_ok=True);f.save(path)
    return dict(context_rules=len(rules),shared_actions=len(actions),added_lookups=len(lookups),existing_lookup_count=offset,
                gpos_before=len(TTFont(base).reader['GPOS']),gpos_after=len(TTFont(path).reader['GPOS']))

def targets():
    out={r['text'] for r in json.loads((REPORT/'before/colliding-fragments.json').read_text(encoding='utf8'))}
    for line in (REPORT/'before/layout-issues.jsonl').open(encoding='utf8'):
        out.update(h['fragment'] for h in json.loads(line)['issues'])
    # Extend earlier tests to dotted shin/sin, previously omitted.
    out.update(c+suffix for c in ['שׁ','שׂ','שּׁ','שּׂ'] for suffix in ['ֹ֙','ֹ֗','ֹ֔'])
    extra=REPORT/'targets-meteg.json'
    if extra.exists():out.update(json.loads(extra.read_text(encoding='utf8')))
    return sorted(out)

def worker_init():
    global _solver,_rasters
    _solver=ComponentShaper(PARENT);_rasters=[ComponentRaster(_solver,k) for k in SIZES]

def worker_job(text):
    try:changes,details=solve_split(_solver,text,_rasters,max_dx=1024)
    except TimeoutError as e:return None,dict(text=text,details=dict(reason=str(e)))
    if changes is None:return None,dict(text=text,details=details)
    return dict(text=text,names=[g['name'] for g in _solver.shape(text,preserve=True)],changes=changes,details=details,source_issues=source_issues(text)),None

def main():
    REPORT.mkdir(parents=True,exist_ok=True);s=ComponentShaper(PARENT)
    fp=hashlib.sha256(PARENT.read_bytes()+Path(__file__).read_bytes()).hexdigest();cache=REPORT/'solutions.json'
    saved=json.loads(cache.read_text(encoding='utf8')) if cache.exists() else {}
    fontsha=hashlib.sha256(PARENT.read_bytes()).hexdigest()
    reusable=saved.get('fingerprint')==fp or saved.get('font_sha256')==fontsha and saved.get('model_version')=='role-host-grid-2'
    previous={r['text']:r for r in saved.get('desired',[])} if reusable else {}
    desired=list(previous.values());failed=[];start=time.time()
    for r in desired:r['changes']={int(i):v for i,v in r['changes'].items()}
    pending=[t for t in targets() if t not in previous]
    def save():dump(cache,dict(fingerprint=fp,font_sha256=fontsha,model_version='role-host-grid-2',desired=sorted(desired,key=lambda r:r['text']),failed=failed))
    print('RESUME',len(desired),'pending',len(pending),flush=True)
    with ProcessPoolExecutor(max_workers=4,initializer=worker_init) as pool:
        futures={pool.submit(worker_job,t):t for t in pending}
        for k,f in enumerate(as_completed(futures),1):
            r,bad=f.result()
            if bad:failed.append(bad);print('UNSOLVED',repr(bad['text']),bad['details'],flush=True)
            else:desired.append(r)
            if k%20==0:
                print('SOLVED',k,'accepted',len(desired),'failed',len(failed),'seconds',round(time.time()-start),flush=True);save()
    save()
    if failed:return
    controls=copy.deepcopy(desired);history=[]
    for iteration in range(10):
        result=export(controls,DEST);after=ComponentShaper(DEST);count=0
        for want,control in zip(desired,controls):
            aa,bb=s.shape(want['text']),after.shape(want['text']);assert len(aa)==len(bb)
            for i,(a,b) in enumerate(zip(aa,bb)):
                dx,dy=want['changes'].get(i,(0,0));ex=dx-(b['x']-a['x']);ey=dy-(b['y']-a['y'])
                if ex or ey:
                    assert a['mark'],(want['text'],a,b);ox,oy=control['changes'].get(i,(0,0));control['changes'][i]=(ox+ex,oy+ey);count+=1
        history.append(count);print('RESPONSE',iteration,count,flush=True)
        if not count:break
    assert history[-1]==0,history
    dump(REPORT/'build.json',dict(export=result,history=history,desired=desired,controls=controls,font_sha256=hashlib.sha256(DEST.read_bytes()).hexdigest()))

if __name__=='__main__':main()
