"""Lossless packing: disjoint SinglePos maps share an action lookup.

The ordered context predicates and the position action observed at every
matched glyph are proved identical. These actions are only invoked by that
context lookup, never by feature lists directly. No broader matching occurs.
"""
from collections import Counter
import copy
from fontTools.ttLib import TTFont
from fontTools.ttLib.tables.DefaultTable import DefaultTable
from fontTools.otlLib.builder import buildSinglePosSubtable,buildLookup,buildValue
from build_sbl_review_v6e import *
from validate_sbl_dictionaries_v6b import xml
from certify_sbl_sefaria_v6d_final import semantics

KEYS=['XPlacement','YPlacement','XAdvance','YAdvance']
def values(lookup):
    assert lookup.LookupType==9 and lookup.LookupFlag==0
    result={}
    for ext in lookup.SubTable:
        assert ext.ExtensionLookupType==1
        st=ext.ExtSubTable;assert st.Format in (1,2)
        for i,n in enumerate(st.Coverage.glyphs):
            v=st.Value if st.Format==1 else st.Value[i]
            assert v is None or not any(k not in KEYS for k in v.__dict__)
            result[n]=tuple(getattr(v,k,0) or 0 for k in KEYS)
    return result

def main(source=DEST,out=OUT/'SBL_BLit-v6e-packed.ttf',report=True):
    count=read(OUT/'build.json')['export']['existing_lookup_count']
    f=TTFont(source,recalcTimestamp=False);g=f['GPOS'].table
    actions={i:values(l) for i,l in enumerate(g.LookupList.Lookup) if count<=i<len(g.LookupList.Lookup)-1}
    groups=[];owners={}
    for idx,vals in sorted(actions.items(),key=lambda kv:(-len(kv[1]),kv[0])):
        possible=[i for i,group in enumerate(groups) if all(n not in group or group[n]==v for n,v in vals.items())]
        if possible:
            k=min(possible,key=lambda i:(len(set(groups[i])|set(vals)),i));groups[k].update(vals)
        else:k=len(groups);groups.append(dict(vals))
        owners[idx]=count+k
    maps=f.getReverseGlyphMap();new=[]
    for group in groups:
        st=buildSinglePosSubtable({n:buildValue({k:v for k,v in zip(KEYS,value) if v}) for n,value in group.items()},maps)
        new.append(buildLookup([st],table='GPOS',extension=True))
    last=len(g.LookupList.Lookup)-1;ctx=copy.deepcopy(g.LookupList.Lookup[last]);newlast=count+len(new)
    for ext in ctx.SubTable:
        st=ext.ExtSubTable
        for rs in st.ChainPosRuleSet:
            for rule in rs.ChainPosRule:
                for rec in rule.PosLookupRecord:rec.LookupListIndex=owners[rec.LookupListIndex]
    for r in g.FeatureList.FeatureRecord:
        assert all(i<count or i==last for i in r.Feature.LookupListIndex)
        r.Feature.LookupListIndex=[newlast if i==last else i for i in r.Feature.LookupListIndex]
    g.LookupList.Lookup=g.LookupList.Lookup[:count]+new+[ctx];g.LookupList.LookupCount=len(g.LookupList.Lookup)
    for tag in f.reader.keys():
        if tag not in ('GPOS','head'):f[tag]=DefaultTable(tag);f[tag].data=f.reader[tag]
    f.save(out);a,b=TTFont(source),TTFont(out)
    assert semantics(a)==semantics(b)
    assert all(xml(a,a['GPOS'].table.LookupList.Lookup[i])==xml(b,b['GPOS'].table.LookupList.Lookup[i]) for i in range(count))
    assert xml(a,a['GPOS'].table.ScriptList)==xml(b,b['GPOS'].table.ScriptList)
    assert a['GPOS'].table.LookupList.Lookup[-1].LookupFlag==b['GPOS'].table.LookupList.Lookup[-1].LookupFlag
    for tag in a.reader.keys():
        if tag not in ('GPOS','head'):assert a.reader[tag]==b.reader[tag]
    expected=copy.deepcopy(a['GPOS'].table.FeatureList)
    for r in expected.FeatureRecord:r.Feature.LookupListIndex=[newlast if i==last else i for i in r.Feature.LookupListIndex]
    assert xml(a,expected)==xml(b,b['GPOS'].table.FeatureList)
    d=dict(reference_sha256=sha(source),font_sha256=sha(out),reference_font=str(source),packed_font=str(out),
        original_action_lookups=len(actions),packed_action_lookups=len(groups),context_rules=read(OUT/'build.json')['export']['context_rules'],
        context_predicates_actions_and_order_identical=True,original_lookup_prefix_unchanged=count,
        actions_only_reachable_from_context_lookup=True,other_tables_identical_except_checksum=True,
        gpos_before=len(a.reader['GPOS']),gpos_after=len(b.reader['GPOS']),bytes_saved=len(a.reader['GPOS'])-len(b.reader['GPOS']))
    if report:dump(OUT/'packing-proof.json',d)
    print(d,flush=True);return d
if __name__=='__main__':main()
