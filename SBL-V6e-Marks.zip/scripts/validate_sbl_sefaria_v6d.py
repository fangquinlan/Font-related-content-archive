"""Full-run regression with exact geometry reuse of the V6c corpus audits.

All original inputs and their NFD forms are shaped again. Reuse is permitted
only with byte-identical outlines/metrics/hinting and identical HarfBuzz
glyph/cluster/advance/offset streams. Changed runs are independently checked.
"""
from collections import Counter
from pathlib import Path
import argparse,json,sqlite3,time,unicodedata as ud
from fontTools.ttLib import TTFont
from build_sbl_sefaria_v6d import BASE,DEST,AUDIT,OUT,read,rows
from audit_maagarim_sbl import ROOT,ComponentShaper,dump,signature,locate
from audit_sbl_merged_v6b import nearby,pairkey,RasterOracle,SIZES,PHASES
from audit_dictionaries_v6b import layout_issues
from certify_sbl_v6c_final import font,shape
from validate_sbl_merged_v6c import all_records,source_path,same_identity
from validate_sbl_dictionaries_v6b import xml
from build_sbl_merged_v6c import hebr_features
from validate_v53 import conventions
from dictionary_corpus_v6b import sha

PRIOR=ROOT/'reports/sbl-v6c-merged-corpus'
DB=ROOT/'data/sefaria-v6c/runs.sqlite3'

def key(h):return tuple(h['names']),tuple(h['clusters'])
def stream_geom(gs):return [(g[0],*g[2:]) for g in gs]
def tables():
    a,b=TTFont(BASE),TTFont(DEST)
    protected=[t for t in a.reader.keys() if t not in ('GPOS','head','name')]
    assert set(a.reader.keys())==set(b.reader.keys())
    assert all(a.reader[t]==b.reader[t] for t in protected)
    ag,bg=a['GPOS'].table,b['GPOS'].table
    assert xml(a,ag.ScriptList)==xml(b,bg.ScriptList)
    assert len(ag.FeatureList.FeatureRecord)==len(bg.FeatureList.FeatureRecord)
    allow=hebr_features(bg)
    for i,r in enumerate(ag.FeatureList.FeatureRecord):
        if i not in allow:assert xml(a,r)==xml(b,bg.FeatureList.FeatureRecord[i])
        else:assert bg.FeatureList.FeatureRecord[i].Feature.LookupListIndex[:r.Feature.LookupCount]==r.Feature.LookupListIndex
    assert all(xml(a,r)==xml(b,bg.LookupList.Lookup[i]) for i,r in enumerate(ag.LookupList.Lookup))
    for nid in (0,7,8,9,13,14):
        names=lambda f:sorted((r.platformID,r.platEncID,r.langID,r.string) for r in f['name'].names if r.nameID==nid)
        assert names(a)==names(b)
    return dict(protected_tables=protected,original_glyphs_outlines_metrics_hinting_unchanged=True,
                existing_lookups_unchanged=len(ag.LookupList.Lookup),legal_names_unchanged=True,
                gpos_before=len(a.reader['GPOS']),gpos_after=len(b.reader['GPOS']))

class Check:
    def __init__(self,phases=PHASES):
        self.s=ComponentShaper(DEST);self.old=ComponentShaper(BASE)
        self.rs=[RasterOracle(self.s,k) for k in SIZES]
        self.phases=phases;self.tested={};self.states=0
    def inspect(self,t,check_layout=False):
        gs=self.s.shape(t);pp=self.s.expand(gs)
        hits=self.s.mark_collisions(pp);locate(t,hits)
        pixel=[]
        for i,j,a,b in nearby(pp):
            k=pairkey(a,b,self.s.font.face.upem)
            if k not in self.tested:
                vals=[];self.states+=1
                for r in self.rs:
                    for p in self.phases:
                        px=r.overlap(k,p)
                        if px:vals.append(dict(size=r.r.size,phase=p,pixels=px))
                self.tested[k]=vals
            if self.tested[k]:pixel.append(dict(key=k,clusters=[a['cl'],b['cl']],contacts=self.tested[k]))
        identity,moved=same_identity(self.old.shape(t),gs)
        result=dict(collisions=hits,raster=pixel,identity=identity,moved_glyphs=len(moved))
        if check_layout:result['layout']=layout_issues(pp,t)
        if len(self.tested)>1000000:self.tested.clear()
        if len(self.s.cache)>300000:self.s.cache.clear();self.old.cache.clear()
        return result

def prior_run(scope):
    started=time.time();a,b=font(BASE),font(DEST);fontsha=sha(DEST)
    prior=read(PRIOR/f'{scope}-validation.json')
    assert prior['font_sha256']==sha(BASE) and not any(prior['failures'].values())
    src=source_path(scope);srcsha=sha(src)
    assert prior['source_sha256']==srcsha
    table=tables();c=Check();counts=Counter();errors=[];changed=[]
    for n,r in enumerate(all_records(scope),1):
        t=r['text'];nf=ud.normalize('NFD',t)
        aa,bb=shape(a,t),shape(b,t);an,bn=shape(a,nf),shape(b,nf)
        counts['runs']+=1;counts['occurrences']+=r.get('count',1)
        if stream_geom(bb)!=stream_geom(bn):errors.append(dict(**r,reason='nfd_geometry'))
        if aa==bb and an==bn:counts['identical_runs']+=1
        else:
            counts['changed_runs']+=1;result=c.inspect(t,True)
            counts['moved_glyphs']+=result['moved_glyphs']
            if any(result[k] for k in ('collisions','raster','identity','layout')):errors.append(dict(**r,**result))
            if stream_geom(bb)!=stream_geom(bn):
                extra=c.inspect(nf,True)
                if any(extra[k] for k in ('collisions','raster','identity','layout')):errors.append(dict(text=nf,**extra))
            changed.append(dict(**r,moved_glyphs=result['moved_glyphs']))
        if n%10000==0:print('REGRESS',scope,n,'changed',counts['changed_runs'],'errors',len(errors),'seconds',round(time.time()-started),flush=True)
    assert counts['runs']==prior['statistics']['runs']
    assert sha(DEST)==fontsha
    result=dict(font_sha256=fontsha,parent_sha256=sha(BASE),source_sha256=srcsha,
                statistics=counts,failures=errors,changed=changed,tables=table,
                raster=dict(sizes=SIZES,phases=PHASES,alpha_threshold='both >153/255',new_states=c.states),
                reference=dict(path=str(PRIOR/f'{scope}-validation.json'),sha256=sha(PRIOR/f'{scope}-validation.json'),
                    method='All raw/NFD streams reshaped; exact geometry equality plus identical outlines/metrics/hinting permits inherited full audit.'),
                seconds=round(time.time()-started,1))
    dump(OUT/f'{scope}-validation.json',result)
    print('DONE',scope,dict(counts),'errors',len(errors),flush=True)

def focused():
    c=Check([p/64 for p in range(64)]);cases=read(OUT/'build.json')['desired'];errors=[]
    for r in cases:
        result=c.inspect(r['text'],True)
        if any(result[k] for k in ('collisions','raster','identity','layout')):errors.append(dict(text=r['text'],**result))
    conv=conventions(c.s)
    # Check every selected pair in its complete original run, not only fragments.
    full={r['run_id']:r['text'] for r in rows(AUDIT/'solver-candidates.jsonl')}
    candidates=rows(AUDIT/'solver-candidates.jsonl');left=[];new=[]
    for rid,t in full.items():
        before=c.old.mark_collisions(c.old.expand(c.old.shape(t)))
        after=c.s.mark_collisions(c.s.expand(c.s.shape(t)))
        oldkeys={key(h) for h in before};newkeys={key(h) for h in after}
        left.extend(r['key'] for r in candidates if r['run_id']==rid and key(r['collision']) in newkeys)
        new.extend(dict(run_id=rid,collision=h) for h in after if key(h) not in oldkeys)
    result=dict(font_sha256=sha(DEST),fragments=len(cases),fragment_failures=errors,
        full_candidate_runs=len(full),candidate_pairs=len(candidates),unresolved_candidate_keys=left,new_vector_pairs=new,
        conventions=dict(checks=len(conv),failures=[r for r in conv if not r['passed']]),tables=tables(),
        raster=dict(sizes=SIZES,phases=c.phases,new_states=c.states,alpha_threshold='both >153/255'))
    dump(OUT/'focused-validation.json',result)
    print('FOCUSED',len(cases),'errors',len(errors),'remaining',len(left),'new',len(new),flush=True)

def sefaria(shard=0,workers=3,quick=False):
    start=time.time();a,b=font(BASE),font(DEST);fontsha=sha(DEST);c=Check();table=tables()
    prior=read(AUDIT/'summary.json');assert prior['font_sha256']==sha(BASE)
    oldhits={r['id']:r for r in rows(AUDIT/'collisions.jsonl')}
    oldpixels={r['id']:r for r in rows(AUDIT/'raster.jsonl')}
    oldnorm={r['id']:r for r in rows(AUDIT/'normalization.jsonl')}
    conn=sqlite3.connect(DB.as_uri()+'?mode=ro',uri=True)
    prefix='quick' if quick else f'sefaria-{shard}'
    checkpoint=OUT/f'{prefix}-progress.json';last=0;stats=Counter()
    if checkpoint.exists():
        old=read(checkpoint)
        if old['font_sha256']==fontsha and old['workers']==workers:
            last=old['last_id'];stats.update(old['statistics'])
    names=['collisions','raster','regressions','changed','normalization']
    fs={k:(OUT/f'{prefix}-{k}.jsonl').open('a' if last else 'w',encoding='utf8') for k in names}
    def write(k,obj):fs[k].write(json.dumps(obj,ensure_ascii=False)+'\n')
    def save():
        for f in fs.values():f.flush()
        dump(checkpoint,dict(font_sha256=fontsha,workers=workers,shard=shard,last_id=last,statistics=stats,seconds=round(time.time()-start,1)))
    selected=set(oldhits)|set(oldpixels)
    while True:
        got=conn.execute('select id,text,count from runs where id>? and id % ? = ? order by id limit 500',(last,workers,shard)).fetchall()
        if not got:break
        for rid,t,count in got:
            last=rid
            if quick and rid not in selected:continue
            aa,bb=shape(a,t),shape(b,t);nf=ud.normalize('NFD',t)
            an,bn=shape(a,nf),shape(b,nf)
            stats['runs']+=1;stats['occurrences']+=count
            record=dict(id=rid,text=t,count=count)
            if stream_geom(bb)!=stream_geom(bn):
                stats['raw_nfd_different_runs']+=1;write('normalization',record)
                if rid not in oldnorm:write('regressions',dict(**record,reason='new_raw_nfd_difference'))
            if aa==bb and an==bn:
                stats['identical_runs']+=1
                hits=oldhits.get(rid,{}).get('collisions',[])
                pixels=oldpixels.get(rid,{}).get('pairs',[])
            else:
                stats['changed_runs']+=1;out=c.inspect(t);hits=out['collisions'];pixels=out['raster']
                stats['moved_glyphs']+=out['moved_glyphs']
                write('changed',dict(**record,moved_glyphs=out['moved_glyphs']))
                oldkeys={key(h):h for h in oldhits.get(rid,{}).get('collisions',[])}
                added=[h for h in hits if key(h) not in oldkeys]
                worse=[h for h in hits if key(h) in oldkeys and h['area']>oldkeys[key(h)]['area']+.5]
                oldp={(tuple(p['key'][:2]),tuple(p['clusters'])) for p in oldpixels.get(rid,{}).get('pairs',[])}
                extrap=[p for p in pixels if (tuple(p['key'][:2]),tuple(p['clusters'])) not in oldp]
                if added or worse or extrap or out['identity']:
                    write('regressions',dict(**record,new_pairs=added,worsened_pairs=worse,new_raster_pairs=extrap,identity=out['identity']))
                if stream_geom(bb)!=stream_geom(bn) and an!=bn:
                    nout=c.inspect(nf)
                    if nout['collisions'] or nout['raster'] or nout['identity']:
                        write('regressions',dict(**record,reason='changed_NFD_failure',nfd=nout))
            if hits:
                stats['collision_runs']+=1;stats['collision_pairs']+=len(hits)
                write('collisions',dict(**record,collisions=hits))
            if pixels:
                stats['raster_runs']+=1;write('raster',dict(**record,pairs=pixels))
            if stats['runs']%10000==0:
                print('SEFARIA',prefix,stats['runs'],'changed',stats['changed_runs'],'seconds',round(time.time()-start),flush=True);save()
        save()
    for f in fs.values():f.close()
    assert sha(DEST)==fontsha
    result=dict(font_sha256=fontsha,parent_sha256=sha(BASE),workers=workers,statistics=stats,tables=table,
        baseline_report_sha256=sha(AUDIT/'summary.json'),database_sha256=read(ROOT/'data/sefaria-v6c/manifest.json').get('database_sha256'),
        raster=dict(sizes=SIZES,phases=PHASES,new_states=c.states,alpha_threshold='both >153/255'),seconds=round(time.time()-start,1))
    dump(OUT/f'{prefix}-complete.json',result)
    print('DONE',prefix,dict(stats),flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('scope',choices=['focused','quick','sefaria','merged','bibles','dictionaries','maagarim'])
    p.add_argument('--shard',type=int,default=0);p.add_argument('--workers',type=int,default=3);a=p.parse_args()
    if a.scope=='focused':focused()
    elif a.scope in ('quick','sefaria'):sefaria(a.shard,1 if a.scope=='quick' else a.workers,a.scope=='quick')
    else:prior_run(a.scope)
