"""Old focused samples and full-context relative-order/host regression."""
from collections import Counter
import argparse,time,unicodedata as ud
from validate_sbl_review_v6e import *
from audit_dictionaries_v6b import center,code,mark_owners

def legacy():
    c=Check([p/64 for p in range(64)]);a,b=font(BASE),font(DEST);counts=Counter();errors=[]
    wanted={r['text'] for r in all_records('focused')}
    wanted.update(r['text'] for r in read(PRIOR/'build.json')['desired'])
    for t in sorted(wanted):
        counts['runs']+=1;nf=ud.normalize('NFD',t)
        if shape(a,t)==shape(b,t) and shape(a,nf)==shape(b,nf):counts['identical_runs']+=1;continue
        counts['changed_runs']+=1;out=c.inspect(t,True)
        if any(out[k] for k in ('collisions','raster','identity','layout')):errors.append(dict(text=t,**out))
    dump(OUT/'legacy-focused-validation.json',dict(font_sha256=sha(DEST),reference_font_sha256=sha(BASE),statistics=counts,failures=errors,
        method='All previous V6c dictionary/merged focused cases and all V6d targets, raw and NFD; recheck changed geometry with 64 phases.'))
    print('LEGACY',dict(counts),'errors',len(errors),flush=True)

def relations():
    for i in range(3):assert read(OUT/f'sefaria-{i}-complete.json')['font_sha256']==sha(DEST)
    full={r['id']:r for i in range(3) for r in rows(OUT/f'sefaria-{i}-changed.jsonl')}
    a,b=ComponentShaper(BASE),ComponentShaper(DEST);errors=[];counts=Counter();holam=[]
    for rid,r in full.items():
        t=r['text'];old=a.expand(a.shape(t));new=b.expand(b.shape(t));counts['changed_full_runs']+=1
        k=lambda h:(h['i'],h['j'],h['reason'])
        before={k(h) for h in layout_issues(old,t)}
        added=[h for h in layout_issues(new,t) if k(h) not in before]
        if added:errors.append(dict(id=rid,text=t,issues=added))
        owners=mark_owners(new)
        for j,(x,y) in enumerate(zip(old,new)):
            if code(y) not in (0x05b9,0x05ba) or (x['x'],x['y'])==(y['x'],y['y']):continue
            host=next((g for g in new if not g['mark'] and g['glyph_index']==owners[j] and g['box']),None)
            if host is None:continue
            counts['moved_holam_host_checks']+=1
            if code(host)!=0x05d5 and center(x)[0]<center(host)[0] and center(y)[0]>=center(host)[0]:
                holam.append(dict(id=rid,cluster=y['cl'],mark=y['name'],host=host['name']))
        if counts['changed_full_runs']%100==0:print('RELATIONS',dict(counts),'errors',len(errors)+len(holam),flush=True)
    dump(OUT/'full-context-relations.json',dict(font_sha256=sha(DEST),statistics=counts,new_layout_failures=errors,new_holam_side_failures=holam,
        source_errors_not_reclassified=True,scope='All full Sefaria runs whose glyph geometry changed; only newly introduced relative-order violations counted.'))
    print('RELATIONS DONE',dict(counts),'errors',len(errors)+len(holam),flush=True)
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('scope',choices=['legacy','relations']);args=p.parse_args()
    if args.scope=='legacy':legacy()
    else:relations()
