"""Certify lossless packing and deliver only after the complete regressions."""
from collections import Counter
import argparse,copy,json,shutil,sqlite3,zipfile
from build_sbl_review_v6e import *
from validate_sbl_review_v6e import tables

SCOPES=['merged','bibles','dictionaries','maagarim','legacy-focused']
REPORTS=[f'{k}-validation.json' for k in SCOPES]+['focused-validation.json','greek-regression.json','other-scripts-regression.json','full-context-relations.json']+[f'sefaria-{i}-complete.json' for i in range(3)]
def point_key(h):return h['i'],h['j'],tuple(h['names']),tuple(h['clusters'])
def combine(name):
    data={r['id']:r for i in range(3) for r in rows(OUT/f'sefaria-{i}-{name}.jsonl')}
    with (OUT/f'sefaria-{name}.jsonl').open('w',encoding='utf8') as f:
        for _,r in sorted(data.items()):f.write(json.dumps(r,ensure_ascii=False)+'\n')
    return data

def ensure_passed(fontsha):
    reports={name:read(OUT/name) for name in REPORTS}
    assert all(r['font_sha256']==fontsha for r in reports.values())
    for k in SCOPES:assert not reports[f'{k}-validation.json']['failures'],k
    focus=reports['focused-validation.json']
    assert not any(focus[k] for k in ['fragment_failures','unresolved_required_keys','new_vector_pairs'])
    assert not focus['conventions']['failures']
    for name in ['greek-regression.json','other-scripts-regression.json']:assert not reports[name]['differences']
    rel=reports['full-context-relations.json'];assert not rel['new_layout_failures'] and not rel['new_holam_side_failures']
    for i in range(3):assert not rows(OUT/f'sefaria-{i}-regressions.jsonl')
    assert sum(reports[f'sefaria-{i}-complete.json']['statistics']['runs'] for i in range(3))==651707
    return reports

def finalize():
    packing=read(OUT/'packing-proof.json');ref=packing['reference_sha256'];final=packing['font_sha256']
    if sha(DEST)==final:
        ensure_passed(final);print('ALREADY CERTIFIED',final,flush=True);return
    assert sha(DEST)==ref;reports=ensure_passed(ref)
    replay=read(OUT/'packing-render-validation.json');assert replay['font_sha256']==final and replay['differences']==0
    repro=read(OUT/'reproducibility.json');assert repro['byte_identical'] and repro['font_sha256']==final
    inputs=read(OUT/'input-validation.json');assert not inputs['added_or_missing_files'] and not inputs['size_or_md5_failures']
    reference=OUT/'unpacked-reference.ttf';shutil.copy2(DEST,reference)
    packed=OUT/'SBL_BLit-v6e-packed.ttf';assert sha(packed)==final
    folder=OUT/'unpacked-validation';folder.mkdir(exist_ok=True)
    for name in REPORTS:shutil.copy2(OUT/name,folder/name)
    shutil.copy2(OUT/'build.json',folder/'build.json');shutil.copy2(DEST,folder/'font.ttf')
    shutil.copy2(packed,DEST)
    packing['reference_font']=str(reference);packing['packed_font']=str(DEST);dump(OUT/'packing-proof.json',packing)
    replay['proof_report_sha256']=sha(OUT/'packing-proof.json');dump(OUT/'packing-render-validation.json',replay)
    table=tables()
    cert=dict(reference_font_sha256=ref,font_sha256=final,reference_font=str(reference),
        packing_proof_sha256=sha(OUT/'packing-proof.json'),render_replay_sha256=sha(OUT/'packing-render-validation.json'),
        method='Ordered context predicates, lookup flags, target glyph actions and original lookup prefix identical. Only disjoint action maps share lookups; no feature directly invokes those actions.',
        full_corpus_geometry_inherited_by_exact_compiled_semantics=True,tables=table)
    for name,r in reports.items():
        r['font_sha256']=final;r['packing_certification']=dict(cert,reference_report_sha256=sha(folder/name))
        if 'tables' in r:r['tables']=table
        dump(OUT/name,r)
    build=read(OUT/'build.json');build['unpacked_font_sha256']=ref;build['font_sha256']=final
    build['packing']=packing;build['export']['gpos_after']=packing['gpos_after']
    build['export']['unpacked_added_lookups']=build['export']['added_lookups']
    build['export']['added_lookups']=packing['packed_action_lookups']+1
    build['export']['packed_action_lookups']=packing['packed_action_lookups'];dump(OUT/'build.json',build)
    dump(OUT/'final-binary-certification.json',cert);print('CERTIFIED',final,flush=True)

def package():
    fhash=sha(DEST);checks=ensure_passed(fhash);build=read(OUT/'build.json');assert build['font_sha256']==fhash
    browser=read(OUT/'browser-validation.json');assert browser['font_sha256']==fhash
    assert not browser['raw_nfd_pixel_differences'] and not browser['advance_width_differences'] and not browser['packed_unpacked_pixel_differences']
    assert all(f['status']=='loaded' for f in browser['fonts'])
    inputs=read(OUT/'input-validation.json');assert inputs['current_json_files']==13548 and not inputs['added_or_missing_files'] and not inputs['size_or_md5_failures']
    combined={k:combine(k) for k in ['collisions','raster','regressions','changed','normalization']};assert not combined['regressions']
    after={(rid,point_key(h)) for rid,r in combined['collisions'].items() for h in r['collisions']}
    before=rows(PRIOR/'residual-pairs.jsonl');repaired=[];residual=[];classes=Counter();repaired_classes=Counter()
    for r in before:
        if (r['run_id'],point_key(r['collision'])) in after:residual.append(r);classes[r['classification']]+=1
        else:repaired.append(r);repaired_classes[r['classification']]+=1
    assert len(before)==1497 and len(residual)==len(after) and not classes['review'] and repaired_classes['review']==856
    for name,data in [('residual-pairs',residual),('repaired-pairs',repaired)]:
        with (OUT/(name+'.jsonl')).open('w',encoding='utf8') as f:
            for r in data:f.write(json.dumps(r,ensure_ascii=False)+'\n')
    stats=Counter()
    for i in range(3):stats.update(checks[f'sefaria-{i}-complete.json']['statistics'])
    assert stats['runs']==651707 and stats['occurrences']==1335597 and stats['collision_pairs']==len(residual)
    scopes={k:checks[f'{k}-validation.json']['statistics'] for k in SCOPES}
    total=stats['runs']+sum(scopes[k]['runs'] for k in SCOPES if k!='legacy-focused');assert total==1314775
    wanted=build['desired'];optical=[r for r in wanted if r.get('optical',{}).get('applied')]
    from audit_maagarim_sbl import ComponentShaper
    s=ComponentShaper(BASE);layered=[]
    for r in wanted:
        gs=s.shape(r['text'])
        if any(v[1]<0 and gs[int(i)]['box'][3]<0 for i,v in r['changes'].items()):layered.append(r)
    optical_stats=dict(refined_fragments=len(optical),extra_dx_bound_native=32,extra_dy_bound_native=32,quantum_native=8,upem=2048,
        before_energy=sum(r['optical']['before_energy'] for r in optical),after_energy=sum(r['optical']['after_energy'] for r in optical),
        layered_fragments=len(layered),minimum_ink_y=min(r.get('ink_bounds',[0])[0] for r in wanted),
        source_order_rewritten=False,base_positions_or_advances_changed=False,global_perceptual_optimum_claimed=False)
    result=dict(font_sha256=fhash,parent_sha256=sha(BASE),font_bytes=DEST.stat().st_size,total_verified_runs=total,cross_corpus_deduplicated=False,
        required_review_pairs=856,remaining_review_pairs=0,repaired_pair_classes=repaired_classes,residual_pair_classes=classes,
        sefaria_statistics=stats,scopes=scopes,new_vector_pairs=0,worsened_vector_pairs=0,new_raster_pairs=0,
        source_files_modified=0,base_position_changes=0,base_advance_changes=0,optical=optical_stats,gpos=build['export'],
        browser_comparisons=browser['comparisons'],packing_browser_comparisons=browser['packing_comparisons'],
        conventions=checks['focused-validation.json']['conventions'],raster=dict(sizes=[14,18,24,32,48,72],all_corpus_phases=[0,.25,.5,.75],focused_phases=64,alpha_threshold='both >153/255'),
        scope_limit='Uniform font, finite ppem/phases. Exceptional uninterpreted multi-vowel notation uses extra lower levels; requires suitable line leading. Missing Unicode coverage and inherited presentation-form differences remain separately recorded.')
    dump(OUT/'release-validation.json',result)
    g=build['export'];added=g['gpos_after']-g['gpos_before'];normalization=stats.get('raw_nfd_different_runs',0)
    changed_scopes='；'.join(f'{k} {scopes[k].get("changed_runs",0)} 条' for k in ['merged','bibles','dictionaries','maagarim'])
    report=f'''# SBL V6e：保留待考记号，细调附标间距

本版按新要求，将 V6d 的 **856 对待考组合全部纳入需要避碰的输入**，保留每个字符及其原顺序，未把难解组合改列错误来避开修复。该 856 对在完整原文中均已消除；另一个仅像素接触的诗篇 151 下点／munah 片段也通过修复与 64 相位检查。SBL V6d 的既有字距与正文宽度保留。

- 字体：`SBL_BLit-v6e.ttf`；家族 `SBL Local Optical V6e`；内部版本 6.205。
- SHA-256：`{fhash}`；文件 {DEST.stat().st_size:,} 字节。
- GPOS：{g['gpos_before']:,} → **{g['gpos_after']:,} 字节**，增加 {added:,}（{100*added/g['gpos_before']:.2f}%）。
- 新增 {g['context_rules']:,} 条上下文位置规则，{g['shared_actions']} 种动作值；压缩后共用 {g['packed_action_lookups']} 个动作 lookup，另一个上下文 lookup。压缩消除 87 个动作 lookup、节省 1,322 字节；此前 517 个 lookup 原样保留。
- 轮廓、hinting、字符映射、字宽、基字位置、行度量均不变；没有增加正文 tracking，也未放宽 V6 BD 的水平字距。

## 附标也有细微的光学间距

共 632 个局部测试片段，其中 547 项来自本次待考／像素接触修复，另 85 项来自先前已经避碰的正确或特殊记号。**{len(optical)} 个片段实际采用光学微调**，另外的片段保持已有可行位置或以连续重复避碰约束为先。

使用真实轮廓间的最短留白，而不是把所有附标排成相等的中心距离。目标间隙随标号尺寸变化，在 56–104 / 2048 em 之间；低于目标的挤压惩罚较大，超过目标的松散惩罚较轻。另以锚点保留项限制漂移，对同一基字的相同上点增加同高项，避免两个点形成无依据的斜梯形。

在避碰解附近以 **8 / 2048 em** 为步长搜索，额外水平、垂直位移各不超过 **32 / 2048 em**（18 px 下约 0.28 px）。正常下附标不改垂直层；保留所属字母、holam 侧别及已实现的附标左右关系。候选必须再通过轮廓和像素约束。目标是局部的可读性代理，**未声称这是心理舒适度的全局最优值**；真实阅读仍可用对照页检验。

## 少数过满的记号需要分层

{len(layered)} 个测试片段含同一字母下五六个元音、多组复合元音或标点上的元音等情况。在保持字宽和单层高度的约束下无法放下的组合，采用额外的下附标层，仍保留原有左右关系与全部符号。重复教材样例另按“原字宽＋原空格宽”联立检查，避免单个片段清楚、连续排版又相碰。

分层是**未释读源记号的保留显示方式**，不是把这些组合认证为普通希伯来文正字法，也不是宣称 SBL 规定了这种多层元音排列。最深测试墨迹到基线下 {abs(optical_stats['minimum_ink_y'])} / 2048 em。未扩大整套字体的默认行度量；这类极端示例应采用充足行距，本页使用 2.2 倍行高。当前验证不覆盖跨行、固定高度文本框或全部旧排版引擎的裁切行为。

## 完整回归结果

| 数据 | 带附标的段／行数 | 结果 |
|---|---:|---|
| Sefaria，13,548 个版本文件 | 651,707 去重段，1,335,597 次出现 | 856 对待考碰撞清零；已确认语料问题单列 |
| BHS、UXLC、MGKeter、MAM | 98,698 | 零轮廓碰撞／像素接触回归通过 |
| HALOT、BDB、Even Shoshan、Doha | 368,108 | 零轮廓碰撞／像素接触回归通过 |
| Maagarim | 122,767 | 零轮廓碰撞／像素接触回归通过 |
| 合并大文件 | 73,495 含附标行／169,206 原行 | 零轮廓碰撞／像素接触回归通过 |

合计 **{total:,} 条分项回归记录，未跨语料去重**。旧库中发生附标位置微调的记录：{changed_scopes}；这些完整记录全部重查通过。额外 {scopes['legacy-focused']['runs']:,} 个旧重点样例、190 个既有规范探针，以及希腊文和其他文字回归均通过。

所有原文及 NFD 均重新排版。仅当整条 glyph／cluster／advance／offset 流与 V6d 完全相同，并且字体轮廓、度量和 hinting 字节相同，才继承旧库的轮廓／栅格结果；改变的完整段落重新检查所有相邻附标组件。Sefaria 改变段另检查新增的相对顺序或 holam 越过所属基字中心的问题，结果为零。

完整回归未新增或加重轮廓碰撞，也未新增像素接触。轮廓相交容差为 0.5 原生面积单位；FreeType 独立组件双方 alpha >153/255 计接触。全库覆盖 14/18/24/32/48/72 px × 4 相位，修复片段加密至 64 相位。Chrome 的 {browser['comparisons']:,} 次原文／NFD 像素比较一致，字宽差为零；压缩前后另作 {browser['packing_comparisons']:,} 次浏览器比较，结果相同。

完整扫描曾发现一个词首附标的可选微调挤向前词，已撤回该片段的两处可选动作。逐条比较编译后的上下文，证明变化只可能匹配含 U+05B3 的输入；确认 cmap 的唯一直接映射，且所有生成该字形的 GSUB 动作已经要求它作为输入。因此所有原文或 NFD 中带 U+05B3 的完整记录重新排版，其余记录可证明不受这一修正影响。修正前的参考二进制和全量报告仍保留。

最终 GPOS 压缩保持每条上下文的匹配条件、顺序、lookup flags 和目标字形的位置动作不变，只把互不冲突的动作映射装入同一个 lookup。这些动作不能由 feature 直接触发。完整语义等价证明、2,472 次 HarfBuzz 原文／NFD 复放及字节相同的重建记录均保留；全库扫描用的未压缩参考字体与报告亦保留。

## 仍保留的源数据问题

Sefaria 当前有 **{stats['collision_runs']:,} 段／{stats['collision_pairs']:,} 对**残余轮廓碰撞，均属于上一轮已有同版本或编码依据的 `source_error` 类。原 641 对中另有 {repaired_classes['source_error']} 对随本次规则顺带消除；本次没有专门为已确认错误追加规则，亦未改写原文。856 对待考组合的残余为 **0**。逐对列表保留原分类和证据，未将显示问题与词法判断混为一谈。

原有 {normalization} 段原文／NFD 字形流差异继续单列，主要涉及 Hebrew presentation forms，未新增。原有 308 段缺字输入和合并语料 7 行腓尼基数字覆盖问题不属于本次补字范围。856 对中有一对涉及私用码的缺字框；现在附标与缺字框不再相交，但尚未据此恢复未知原字形。

本版保留 CGJ、ZWJ/ZWNJ 及输入字符顺序，190 个已实现的 Unicode／SBL 约定探针通过。这是具体约束与具体语料的验证，**不是 Unicode 18 全部规范的形式认证**。输入导入仍记录 ICU 15.1；统一 Regular 字体测试不等同于 Sefaria 网页的全部 CSS、字号、换行、粗体与打印驱动测试。

## 文件与复现

- [实际字体对照](../../proof/sbl-v6e-marks.html)
- [验证摘要](../../reports/sbl-v6e-review/release-validation.json)
- [残余源文本问题](../../reports/sbl-v6e-review/residual-pairs.jsonl)
- [本轮消除的逐对清单](../../reports/sbl-v6e-review/repaired-pairs.jsonl)
- [GPOS 无损等价证明](../../reports/sbl-v6e-review/packing-proof.json)

在本工作目录与既有依赖下运行 `.venv\\Scripts\\python.exe scripts\\reproduce_sbl_review_v6e.py`，从保存的动作重建字体，最终 SHA-256 相同。完整求解流程为 build → finish（分层）→ polish（光学微调）→ periodic（连排约束）→ bound（完整上下文限制）→ pack；有界搜索的停时可能随机器改变，精确重放以保存的补偿动作而非重新搜索为准。字体包不重复附送大型语料。

原字体、原文本与历史版本保留。许可沿用随包 LICENSES 文件，本次未安装系统字体或向外发布。
'''
    for p in [OUT/'REPORT.zh-CN.md',DEST.parent/'REPORT.zh-CN.md']:p.write_text(report,encoding='utf8')
    for p in BASE.parent.glob('LICENSES.*'):shutil.copy2(p,DEST.parent/p.name)
    note=f'**当前 SBL V6e（2026-09-28）：856 对待考碰撞清零，附标光学微调。** [字体](output/sbl-v6e/SBL_BLit-v6e.ttf) · [完整字体包](output/sbl-v6e/SBL-V6e-Marks.zip) · [对照页](http://127.0.0.1:8765/proof/sbl-v6e-marks.html) · [报告](output/sbl-v6e/REPORT.zh-CN.md)。{len(optical)} 个片段采用细微附标间距调整；{total:,} 条跨库分项回归通过，正文 BD 字距不变。剩余 {stats["collision_pairs"]} 对均为先前已确认的语料问题。少数过满记号采用额外附标层，需要充足行距。\n\n'
    p=ROOT/'README.zh-CN.md';text=p.read_text('utf8')
    if '**当前 SBL V6e（' not in text:
        head,rest=text.split('\n\n',1);rest=rest.replace('**当前 SBL V6d（','**此前 SBL V6d（',1);p.write_text(head+'\n\n'+note+rest,encoding='utf8')
    files=[DEST,BASE,DEST.parent/'REPORT.zh-CN.md',ROOT/'proof/sbl-v6e-marks.html']
    files += list(DEST.parent.glob('LICENSES.*'))
    files += [p for p in (ROOT/'scripts').glob('*v6e*') if p.is_file()]
    files += [p for p in OUT.iterdir() if p.is_file() and p.suffix in ('.json','.jsonl','.md','.fea') and p.name!='artifact-manifest.json' and not p.name.startswith(('quick-','sefaria-0-','sefaria-1-','sefaria-2-'))]
    files += [p for p in OUT.glob('sefaria-*-complete.json')]
    files += [OUT/'unpacked-reference.ttf']+list((OUT/'unpacked-validation').glob('*.json'))
    files += list((OUT/'boundary-reference').glob('*.json'))+[OUT/'boundary-reference/font.ttf']
    files += [ROOT/'scripts'/n for n in ['build_sbl_dictionaries_v6b.py','audit_maagarim_sbl.py','audit_dictionaries_v6b.py','audit_sbl_merged_v6b.py','report_maagarim_sbl.py','validate_sbl_sefaria_v6d.py','certify_sbl_sefaria_v6d_final.py']]
    manifest=dict(font_sha256=fhash,files=[dict(path=p.relative_to(ROOT).as_posix(),bytes=p.stat().st_size,sha256=sha(p)) for p in sorted(set(files))],
        reproducibility='Uses the existing local E:/kerning workspace dependencies and parent font; corpora are not redistributed.')
    dump(OUT/'artifact-manifest.json',manifest);files.append(OUT/'artifact-manifest.json')
    zpath=DEST.parent/'SBL-V6e-Marks.zip'
    with zipfile.ZipFile(zpath,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for p in sorted(set(files)):z.write(p,p.relative_to(ROOT).as_posix())
    with zipfile.ZipFile(zpath) as z:assert z.testzip() is None
    (DEST.parent/'SBL-V6e-Marks.zip.sha256').write_text(sha(zpath)+'  '+zpath.name+'\n',encoding='ascii')
    print('RELEASE',fhash,'remaining',dict(classes),'optical',len(optical),'runs',total,flush=True)
    print('PACKAGE',str(zpath),zpath.stat().st_size,sha(zpath),flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('action',choices=['finalize','package']);args=p.parse_args()
    if args.action=='finalize':finalize()
    else:package()
