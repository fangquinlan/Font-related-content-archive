"""Audit the exact, complete merged corpus without changing text or fonts.

The original line boundaries and punctuation are retained. Composite Hebrew
glyphs are expanded to expose dots/vowels embedded by GSUB. Raster checks are
diagnostics for all geometrically close component pairs, not just edited marks.
"""
from collections import Counter
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path
import argparse, hashlib, json, math, sqlite3, time, unicodedata as ud
import numpy as np
from audit_maagarim_sbl import ROOT,ComponentShaper,signature,locate,dump
from audit_dictionaries_v6b import layout_issues,source_issues
from dictionary_corpus_v6b import sha
from report_maagarim_sbl import ComponentRaster

SOURCE=ROOT/'hebrew_all_pointed_variants.txt'
ORIGINAL=Path(r'E:\Bible\cleaned_hebrew')
FONT=ROOT/'output/sbl-v6b/SBL_BLit-v6b.ttf'
OUT=ROOT/'reports/sbl-v6b-merged-corpus'
SIZES=[14,18,24,32,48,72]
PHASES=[0,.25,.5,.75]

def nearby(pp,margin=320):
    boxes=[]
    for i,g in enumerate(pp):
        if g['box']:
            a,b,c,d=g['box'];boxes.append((a+g['x'],b+g['y'],c+g['x'],d+g['y'],i))
    boxes.sort()
    for k,a in enumerate(boxes):
        for j in range(k+1,len(boxes)):
            b=boxes[j]
            if b[0]>a[2]+margin:break
            if b[1]>a[3]+margin or a[1]>b[3]+margin:continue
            i1,i2=sorted((a[4],b[4]));u,v=pp[i1],pp[i2]
            if not (u['mark'] or v['mark']):continue
            yield i1,i2,u,v

def pairkey(a,b,upem):
    # Translation by an integer em is an integer pixel at every tested size.
    # Keep absolute vertical placement and the exact residual horizontal phase.
    x=a['x']%upem
    return (a['name'],b['name'],x,a['y'],b['x']-a['x'],b['y'],a['glyph_index']==b['glyph_index'])

def scan_chunk(job):
    chunk,rows=job;s=ComponentShaper(FONT);stats=Counter();pairs={};hits=[];roles=[];norm=[];missing=[];tokens=Counter();start=time.time()
    for lineno,t in rows:
        stats['lines']+=1
        # Every codepoint is inventoried by the coordinator, including unpointed
        # lines. Only lines carrying marks can have a mark collision.
        if not any(ud.category(c).startswith('M') for c in t):continue
        stats['marked_lines']+=1;gs=s.shape(t);pp=s.expand(gs);stats['glyphs']+=len(gs)
        for word in t.split():
            if any(ud.category(c).startswith('M') for c in word):tokens[word]+=1
        cs=s.mark_collisions(pp);locate(t,cs)
        if cs:hits.append(dict(line=lineno,text=t,collisions=cs,source_issues=source_issues(t)))
        rr=layout_issues(pp,t);locate(t,rr)
        if rr:roles.append(dict(line=lineno,text=t,issues=rr))
        if any(g['name']=='.notdef' for g in gs):missing.append(dict(line=lineno,text=t))
        nfd=ud.normalize('NFD',t)
        if signature(gs)!=signature(s.shape(nfd)):
            npp=s.expand(s.shape(nfd));nc=s.mark_collisions(npp);locate(nfd,nc)
            norm.append(dict(line=lineno,text=t,nfd=nfd,raw_collisions=cs,nfd_collisions=nc))
        for i,j,a,b in nearby(pp):
            key=pairkey(a,b,s.font.face.upem)
            if key not in pairs:pairs[key]=dict(count=0,lines=[],example=dict(line=lineno,clusters=[a['cl'],b['cl']]))
            r=pairs[key];r['count']+=1
            if not r['lines'] or r['lines'][-1]!=lineno:r['lines'].append(lineno)
        if stats['marked_lines']%5000==0:
            print('SCAN',chunk,'marked',stats['marked_lines'],'collision_lines',len(hits),'near_states',len(pairs),'seconds',round(time.time()-start),flush=True)
    result=dict(statistics=stats,collisions=hits,layout=roles,normalization=norm,missing=missing,
                pairs=[dict(key=list(k),**v) for k,v in pairs.items()],tokens=tokens)
    p=OUT/f'chunk-{chunk}.json';dump(p,result)
    return str(p)

def inventory():
    OUT.mkdir(parents=True,exist_ok=True)
    assert sha(SOURCE)==sha(ORIGINAL/SOURCE.name),'copies differ'
    lines=SOURCE.read_text(encoding='utf-8-sig').splitlines();chars=Counter(''.join(lines));s=ComponentShaper(FONT)
    con=sqlite3.connect((ORIGINAL/'corpus.sqlite3').as_uri()+'?mode=ro',uri=True)
    rows=con.execute('select id,text from texts order by id').fetchall();con.close()
    assert [r[1] for r in rows]==lines,'provenance database text differs'
    prior=json.loads((ROOT/'data/hebrew-v5.4/bible-verses.json').read_text(encoding='utf8'))
    prior_exact={r['text'] for r in prior};prior_nfd={ud.normalize('NFD',t) for t in prior_exact}
    prior_tokens={ud.normalize('NFD',w) for t in prior_exact for w in t.split()}
    marked_lines=[t for t in lines if any(ud.category(c).startswith('M') for c in t)]
    tokens={w for t in marked_lines for w in t.split() if any(ud.category(c).startswith('M') for c in w)}
    missing={f'U+{ord(c):04X}':dict(name=ud.name(c,'?'),count=n) for c,n in chars.items() if ord(c) not in s.tt.getBestCmap() and not c.isspace() and ud.category(c)!='Cf'}
    meta=dict(source=str(SOURCE),source_sha256=sha(SOURCE),source_bytes=SOURCE.stat().st_size,
        original_identical_copy=str(ORIGINAL/SOURCE.name),font=str(FONT),font_sha256=sha(FONT),
        line_count=len(lines),marked_lines=len(marked_lines),unmarked_lines=len(lines)-len(marked_lines),
        max_line_characters=max(map(len,lines)),pointed_token_types=len(tokens),
        exactly_matching_previous_bible_lines=sum(t in prior_exact for t in marked_lines),
        nfd_matching_previous_bible_lines=sum(ud.normalize('NFD',t) in prior_nfd for t in marked_lines),
        pointed_token_types_outside_previous_bibles=sum(ud.normalize('NFD',w) not in prior_tokens for w in tokens),
        missing_codepoints=missing,
        missing_codepoint_lines=[i for i,t in enumerate(lines,1) if any(f'U+{ord(c):04X}' in missing for c in t)],
        combining_characters={f'U+{ord(c):04X}':dict(name=ud.name(c,'?'),count=n) for c,n in chars.items() if ud.category(c).startswith('M')},
        provenance_database_sha256=sha(ORIGINAL/'corpus.sqlite3'),
        source_statistics=json.loads((ORIGINAL/'statistics.json').read_text(encoding='utf8')),
        line_to_variant_id=[i for i,t in rows])
    dump(OUT/'inventory.json',meta)
    return lines,meta

def scan(workers):
    start=time.time();lines,meta=inventory();batch=math.ceil(len(lines)/workers)
    jobs=[(i,list(enumerate(lines[i*batch:(i+1)*batch],i*batch+1))) for i in range(workers)]
    with ProcessPoolExecutor(max_workers=workers) as pool:
        for job in as_completed([pool.submit(scan_chunk,j) for j in jobs]):print('CHUNK DONE',job.result(),flush=True)
    results=[json.loads((OUT/f'chunk-{i}.json').read_text(encoding='utf8')) for i in range(workers)]
    allpairs={};stats=Counter();tokens=Counter()
    for r in results:
        stats.update(r['statistics']);tokens.update(r['tokens'])
        for p in r['pairs']:
            key=tuple(p['key'])
            if key not in allpairs:allpairs[key]=p
            else:allpairs[key]['count']+=p['count'];allpairs[key]['lines']+=p['lines']
    for field in ['collisions','layout','normalization','missing']:
        values=sorted([v for r in results for v in r[field]],key=lambda v:v['line'])
        dump(OUT/(field+'.json'),values)
        stats[field+'_lines']=len(values)
    dump(OUT/'nearby-pair-states.json',list(allpairs.values()))
    dump(OUT/'pointed-token-counts.json',tokens)
    result=dict(font_sha256=meta['font_sha256'],source_sha256=meta['source_sha256'],statistics=stats,
        distinct_nearby_pair_states=len(allpairs),vector_tolerance_native_area=.5,
        composite_components=True,raw_and_nfd=True,original_full_line_context=True,seconds=round(time.time()-start,1))
    assert sha(FONT)==meta['font_sha256'] and sha(SOURCE)==meta['source_sha256']
    dump(OUT/'scan-summary.json',result);print('VECTOR COMPLETE',json.dumps(result,ensure_ascii=False),flush=True)

class RasterOracle:
    """Memoize exact FreeType 26.6 placement, including observed pixel phase."""
    def __init__(self,s,size):
        self.r=ComponentRaster(s,size);self.scale=size/s.font.face.upem;self.cache={};self.gids=s.tt.getReverseGlyphMap()
    def overlap(self,key,phase):
        na,nb,x,ya,dx,yb,_=key
        ax=x*self.scale+phase;ay=ya*self.scale;bx=(x+dx)*self.scale+phase;by=yb*self.scale
        ia,ja,ib,jb=math.floor(ax),math.floor(ay),math.floor(bx),math.floor(by)
        fa,ga,fb,gb=round((ax-ia)*64),round((ay-ja)*64),round((bx-ib)*64),round((by-jb)*64)
        k=(self.gids[na],self.gids[nb],fa,ga,fb,gb,ib-ia,jb-ja)
        if k not in self.cache:
            a,al,at=self.r.mask(k[0],fa/64,ga/64);b,bl,bt=self.r.mask(k[1],fb/64,gb/64)
            ax0,ay0=al,-at;bx0,by0=bl+k[6],-bt-k[7]
            x0,y0=max(ax0,bx0),max(ay0,by0);x1,y1=min(ax0+a.shape[1],bx0+b.shape[1]),min(ay0+a.shape[0],by0+b.shape[0])
            value=0 if x0>=x1 or y0>=y1 else int(np.sum((a[y0-ay0:y1-ay0,x0-ax0:x1-ax0]>153)&(b[y0-by0:y1-by0,x0-bx0:x1-bx0]>153)))
            self.cache[k]=value
        return self.cache[k]

def raster_chunk(job):
    ix,path=job;rows=json.loads(Path(path).read_text(encoding='utf8'))['pairs']
    s=ComponentShaper(FONT);rasters=[RasterOracle(s,k) for k in SIZES];bad=[];start=time.time()
    for n,r in enumerate(rows,1):
        contacts=[]
        for raster in rasters:
            for phase in PHASES:
                pixels=raster.overlap(r['key'],phase)
                if pixels:contacts.append(dict(size=raster.r.size,phase=phase,pixels=pixels))
        if contacts:bad.append(dict(**r,contacts=contacts))
        if n%100000==0:print('RASTER',ix,n,len(rows),'contact_states',len(bad),'seconds',round(time.time()-start),flush=True)
    dump(OUT/f'raster-chunk-{ix}.json',bad)
    return dict(contact_states=len(bad),tested_states=len(rows),exact_raster_states=sum(len(r.cache) for r in rasters))

def raster(workers):
    start=time.time();meta=json.loads((OUT/'inventory.json').read_text(encoding='utf8'))
    assert sha(FONT)==meta['font_sha256']
    jobs=list(enumerate(str(p) for p in sorted(OUT.glob('chunk-*.json'))));totals=Counter()
    with ProcessPoolExecutor(max_workers=workers) as pool:
        for job in as_completed([pool.submit(raster_chunk,j) for j in jobs]):
            value=job.result();totals.update(value);print('RASTER CHUNK DONE',value,flush=True)
    groups={}
    for i,path in jobs:
        for r in json.loads((OUT/f'raster-chunk-{i}.json').read_text(encoding='utf8')):
            k=tuple(r['key'])
            if k not in groups:groups[k]=r
            else:groups[k]['count']+=r['count'];groups[k]['lines']+=r['lines']
    bad=list(groups.values())
    dump(OUT/'raster-contacts.json',bad)
    scan_result=json.loads((OUT/'scan-summary.json').read_text(encoding='utf8'))
    result=dict(font_sha256=meta['font_sha256'],source_sha256=meta['source_sha256'],pair_states=scan_result['distinct_nearby_pair_states'],
        computation=totals,
        contact_pair_states=len(bad),contact_lines=len({n for r in bad for n in r['lines']}),
        independent_glyph_contact_lines=len({n for r in bad if not r['key'][-1] for n in r['lines']}),
        sizes=SIZES,phases=PHASES,alpha_threshold=.6,nearby_bbox_margin_native=320,
        note='Independent component-mask overlaps are raster diagnostics, including components inside composite glyphs; not all are new outline intersections.',
        seconds=round(time.time()-start,1))
    assert sha(FONT)==meta['font_sha256'];dump(OUT/'raster-summary.json',result)
    print('RASTER COMPLETE',json.dumps(result,ensure_ascii=False),flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--stage',choices=['scan','raster'],default='scan');p.add_argument('--workers',type=int,default=3);a=p.parse_args()
    (scan if a.stage=='scan' else raster)(a.workers)
