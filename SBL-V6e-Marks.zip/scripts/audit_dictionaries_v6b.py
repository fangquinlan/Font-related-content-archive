"""Expanded-outline collision and source-semantic audit of dictionary runs."""
from collections import Counter
from pathlib import Path
import argparse, hashlib, json, re, time, unicodedata as ud
from audit_maagarim_sbl import ComponentShaper, signature, locate, dump, ROOT
from dictionary_corpus_v6b import OUT as DATA, sha

REPORT=ROOT/'reports/sbl-v6b-dictionaries'
PARENT=ROOT/'output/sbl-v6a/SBL_BLit-v6a.ttf'

def center(g):return (g['x']+(g['box'][0]+g['box'][2])/2,g['y']+(g['box'][1]+g['box'][3])/2)
def code(g):
    m=re.fullmatch(r'uni([0-9A-F]{4})(?:\..*)?',g['name'])
    return int(m[1],16) if m else None

POSTPOSITIVE={0x0592,0x0599,0x05a9,0x05ae}

def stress_helper(g,text):
    """A repeated accent inside the word is a centered stress helper.

    The source uses the same code point for both functions. Preserve SBL's
    contextual medial form; do not push it into the word-final accent lane.
    """
    if text is None or code(g) not in (0x0592,0x05a9):return False
    cl=g['cl'];end=cl
    while end<len(text) and not text[end].isspace() and text[end] not in '\u05c3\u05c0':end+=1
    rest=text[cl:end];mark=chr(code(g));first=rest.find(mark)
    return first>=0 and mark in rest[first+1:] and any('א'<=c<='ת' for c in rest[first+1:])

def mark_owners(parts):
    """Recover attachment hosts inside HB clusters that span two consonants.

    SBL's Jerusalem substitution moves hiriq to a final-mem composite while
    retaining lamed and its other marks in the same HB cluster. That hiriq
    must not impose lamed-mark ordering constraints. In RTL output, ordinary
    separate marks precede their host glyph; embedded parts own their parent.
    """
    bases={}
    for g in parts:
        if not g['mark'] and g['box']:bases.setdefault(g['cl'],set()).add(g.get('glyph_index',id(g)))
    out=[]
    for g in parts:
        i=g.get('glyph_index',id(g));choices=sorted(bases.get(g['cl'],()))
        owner=i if i in choices else next((n for n in choices if n>=i),choices[-1] if choices else None)
        out.append(owner)
    return out

def layout_issues(parts,text=None):
    """Test relative lanes using actual embedded mark components as well."""
    clusters={};out=[];owners=mark_owners(parts)
    for i,g in enumerate(parts):
        if g['box']:clusters.setdefault(owners[i],[]).append((i,g))
    for owner,group in clusters.items():
        bases=[g for i,g in group if not g['mark'] and code(g) and 0x05d0<=code(g)<=0x05ea]
        if not bases:continue
        cl=bases[0]['cl'];basecode=code(bases[0])
        end=min([p['cl'] for p in parts if p['cl']>cl]+[len(text or '')])
        cluster=text[cl:end] if text is not None else ''
        # CGJ protects alternate annotation sequences. Their relative layout
        # is separately covered by explicit SBL control-sequence probes.
        if '\u034f' in cluster:continue
        for i,a in group:
            ac=code(a)
            if ac not in (0x05b9,0x05ba) and not (ac and 0x05b0<=ac<=0x05b8 or ac in (0x05bb,0x05c7)):continue
            ax,ay=center(a)
            for j,b in group:
                bc=code(b);bx,by=center(b)
                reason=None
                if ac in (0x05b9,0x05ba) and bc and 0x0591<=bc<=0x05ae and by>700:
                    if stress_helper(b,text):continue
                    if bc in POSTPOSITIVE and bx>=ax:reason='postpositive_accent_must_be_left_of_holam'
                    elif bc not in POSTPOSITIVE and bx<=ax:reason='upper_accent_must_be_right_of_holam'
                if basecode==0x05e9 and ac in (0x05b9,0x05ba) and bc==0x05c2 and ax>=bx:reason='holam_must_be_left_of_sin_dot'
                if ay<0 and bc and 0x0591<=bc<=0x05ae and by<0:
                    if bc in (0x059a,0x05ad) and bx<=ax:reason='prepositive_accent_must_be_right_of_vowel'
                    elif bc not in (0x059a,0x05ad) and bx>=ax:reason='lower_accent_must_be_left_of_vowel'
                if ay<0 and bc==0x05bd and text is not None:
                    if not any(c in cluster for c in '\u034f\u200d\u200c') and ac not in (0x05b1,0x05b2,0x05b3) and bx>=ax:reason='default_meteg_must_be_left_of_vowel'
                if reason:out.append(dict(i=i,j=j,clusters=[cl,cl],names=[a['name'],b['name']],reason=reason))
    return out

def source_issues(t):
    out=[]
    for m in re.finditer(r'([^\u0591-\u05bd\u05bf\u05c1\u05c2\u05c4\u05c5\u05c7-\u05c9\u0300-\u036f])([\u0591-\u05bd\u05bf\u05c1\u05c2\u05c4\u05c5\u05c7-\u05c9\u0300-\u036f]+)',ud.normalize('NFD',t)):
        b,marks=m.groups();reasons=[]
        if any(c in marks for c in '\u05c1\u05c2') and b!='ש':reasons.append('shin_or_sin_dot_on_other_base')
        if '\u05c1' in marks and '\u05c2' in marks:reasons.append('both_shin_and_sin_dot')
        if '\u05ba' in marks and b!='ו':reasons.append('holam_haser_on_other_base')
        if len(set(marks))!=len(marks):reasons.append('repeated_combining_character')
        if len([c for c in marks if 0x05b0<=ord(c)<=0x05b8 or ord(c) in (0x05bb,0x05c7,0x05c8)])>1:reasons.append('multiple_lower_vowels_editorial_or_source_error')
        if not ('א'<=b<='ת'):reasons.append('isolated_or_editorial_mark_on_nonletter')
        if reasons:out.append(dict(cluster=m[0],nfd_start=m.start(),reasons=reasons))
    return out

def scan(font,dest):
    dest.mkdir(parents=True,exist_ok=True);s=ComponentShaper(font);stats=Counter();by_source={};pairs=Counter();fragments={};start=time.time()
    outputs={name:(dest/(name+'.jsonl')).open('w',encoding='utf8') for name in ['colliding-runs','normalization-differences','missing-glyph-runs','source-issues','layout-issues']}
    with (DATA/'hebrew-runs.jsonl').open(encoding='utf8') as src:
        for n,line in enumerate(src,1):
            r=json.loads(line);t=r['text'];stats['unique_runs']+=1;stats['run_occurrences']+=r['count'];stats['characters']+=len(t)
            for name,count in r['sources'].items():
                c=by_source.setdefault(name,Counter());c['unique_runs']+=1;c['run_occurrences']+=count
            aa=s.shape(t);parts=s.expand(aa);hits=s.mark_collisions(parts);locate(t,hits)
            roles=layout_issues(parts,t);locate(t,roles)
            if roles:
                stats['layout_issue_runs']+=1;stats['layout_issue_pairs']+=len(roles)
                outputs['layout-issues'].write(json.dumps(dict(**r,issues=roles),ensure_ascii=False)+'\n')
            missing=[g for g in aa if g['name']=='.notdef']
            if missing:
                stats['missing_glyph_runs']+=1;outputs['missing-glyph-runs'].write(json.dumps(dict(**r,missing=missing),ensure_ascii=False)+'\n')
            nf=ud.normalize('NFD',t)
            if nf!=t:
                stats['nfd_different_strings']+=1;bb=s.shape(nf)
                if signature(aa)!=signature(bb):
                    stats['nfd_geometry_differences']+=1
                    outputs['normalization-differences'].write(json.dumps(dict(**r,nfd=nf,collisions=s.mark_collisions(s.expand(bb))),ensure_ascii=False)+'\n')
            issues=source_issues(t)
            if issues:
                stats['source_issue_runs']+=1
                outputs['source-issues'].write(json.dumps(dict(**r,issues=issues),ensure_ascii=False)+'\n')
            if hits:
                stats['colliding_runs']+=1;stats['collision_pairs']+=len(hits);stats['colliding_occurrences']+=r['count']
                outputs['colliding-runs'].write(json.dumps(dict(**r,collisions=hits),ensure_ascii=False)+'\n')
                for name,count in r['sources'].items():
                    by_source[name]['colliding_unique_runs']+=1;by_source[name]['colliding_occurrences']+=count
                for h in hits:
                    pair=' / '.join(h['names']);pairs[pair]+=1;f=h['fragment']
                    ent=fragments.setdefault(f,dict(text=f,count=0,pairs=Counter(),sources=Counter(),examples=[],max_area=0))
                    ent['count']+=r['count'];ent['pairs'][pair]+=1;ent['sources'].update(r['sources']);ent['max_area']=max(ent['max_area'],h['area'])
                    if len(ent['examples'])<2:ent['examples'].append(dict(ref=r['examples'][0],text=t,collision=h))
            if n%20000==0:
                print('AUDIT',n,dict(stats),'seconds',round(time.time()-start),flush=True)
    for f in outputs.values():f.close()
    dump(dest/'colliding-fragments.json',sorted(fragments.values(),key=lambda r:(-r['count'],-r['max_area'])))
    result=dict(font=str(font.relative_to(ROOT)),font_sha256=sha(font),corpus_sha256=sha(DATA/'hebrew-runs.jsonl'),
                statistics=stats,by_source=by_source,fragments=len(fragments),pair_types=pairs,
                vector_tolerance_native_area=.5,expanded_composite_marks=True,raw_nfd_checked=True,seconds=round(time.time()-start,1))
    dump(dest/'scan.json',result);print('DONE',json.dumps(result,ensure_ascii=False),flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--font',type=Path,default=PARENT);p.add_argument('--out',type=Path,default=REPORT/'before');args=p.parse_args();scan(args.font.resolve(),args.out)
