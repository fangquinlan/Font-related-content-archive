"""Small, contour-aware optical spacing of positioned combining marks.

This is a local extension of BD, not reuse of Greek target distances. Glyph
outlines and base advances are frozen. A compact-support counterspace loss,
position prior and repeated-mark level coherence rank 8-unit moves. Exact
outline constraints and multi-size/phase raster non-contact remain mandatory.
The soft gap target scales with the participating mark heights (56–104 units).
"""
from collections import Counter
import copy,math
from audit_dictionaries_v6b import center,code,layout_issues
from build_sbl_dictionaries_v6b import shifted,role_edges
from audit_sbl_merged_v6b import nearby,pairkey,RasterOracle,SIZES

def gap(s,a,b,cap=144):
    if not s.near(a,b,cap):return cap
    lo,hi=0,cap
    if s.near(a,b,0):return 0
    while hi-lo>4:
        mid=(lo+hi)//2
        if s.near(a,b,mid):hi=mid
        else:lo=mid
    return (lo+hi)/2

def refine(s,text,changes,extra_active=None):
    origin=s.shape(text);hard=[shifted(g,*changes.get(i,(0,0))) for i,g in enumerate(origin)]
    parts=s.expand(hard);active={i for i,g in enumerate(hard) if g['mark'] and g['box'] and
        (i in changes or g['cl'] in {origin[j]['cl'] for j in changes} or i in (extra_active or set()))}
    # Embedded dagesh/shin dots are immutable; microspacing affects free marks.
    active={i for i in active if sum(p['glyph_index']==i for p in parts)==1 and hard[i]['name'] not in ('uni05BC','uni05C1','uni05C2')}
    if not active:return changes,dict(applied=False,reason='no free target marks')
    edges=role_edges(parts,text);pairs=[]
    for i,j,a,b in nearby(parts):
        if not a['mark'] or not b['mark']:continue
        if a['glyph_index'] not in active and b['glyph_index'] not in active:continue
        ga=gap(s,a,b)
        if ga>=144:continue
        heights=[p['box'][3]-p['box'][1] for p in (a,b)]
        target=max(56,min(104,round(.22*min(heights)/8)*8))
        pairs.append((i,j,target))
    if not pairs:return changes,dict(applied=False,reason='no nearby mark pairs')
    def score(gs):
        pp=s.expand(gs);energy=0;distances=[]
        for i,j,target in pairs:
            a,b=pp[i],pp[j];d=gap(s,a,b);distances.append(d)
            # Penalize crowding heavily, over-opening gently; no force outside
            # the original small neighbourhood and no universal equal gaps.
            energy+=(max(0,target-d)/48)**2+.10*(max(0,d-target)/80)**2
            if a['name']==b['name'] and a['cl']==b['cl']:
                energy+=.7*((a['y']-b['y'])/32)**2
        energy+=.10*sum(((g['x']-hard[i]['x'])/32)**2+2*((g['y']-hard[i]['y'])/32)**2 for i,g in enumerate(gs))
        return energy,distances
    def feasible(gs):
        pp=s.expand(gs)
        if any(center(pp[i])[0]>=center(pp[j])[0] for i,j in edges):return False
        for i in active:
            g=gs[i];upper=center(g)[1]>700
            if not upper and g['y']!=hard[i]['y']:return False
            if upper and (g['y']<hard[i]['y']-32 or g['y']+g['box'][3]>2192):return False
            host=next((b for b in gs if not b['mark'] and b['box'] and b['cl']==g['cl']),None)
            if host:
                lo=min(host['x']-128,center(hard[i])[0]-32);hi=max(host['x']+host['advance']+128,center(hard[i])[0]+32)
                if not lo<=center(g)[0]<=hi:return False
                if code(g) in (0x05b9,0x05ba) and host['name']!='uni05D5' and center(g)[0]>=center(host)[0]:return False
        return not s.mark_collisions(pp) and not layout_issues(pp,text)
    current=hard;start_score=score(current);best_score=start_score
    for iteration in range(5):
        improved=False
        for i in sorted(active):
            best=current;cost=best_score
            for dx,dy in [(8,0),(-8,0),(16,0),(-16,0),(0,8),(0,-8),(0,16),(0,-16)]:
                g=current[i]
                if abs(g['x']+dx-hard[i]['x'])>32 or abs(g['y']+dy-hard[i]['y'])>32:continue
                trial=list(current);trial[i]=shifted(g,dx,dy)
                if not feasible(trial):continue
                val=score(trial)
                if val[0]<cost[0]-1e-9:best,cost=trial,val
            if best is not current:current,best_score=best,cost;improved=True
        if not improved:break
    if current is hard:return changes,dict(applied=False,before_energy=start_score[0],after_energy=best_score[0],pair_targets=[v[2] for v in pairs])
    # Acceptance depends on all touched component pairs, not only the pairs
    # optimized. Final build additionally tests 64 phases.
    pp=s.expand(current);oracles=[RasterOracle(s,z) for z in SIZES]
    for _,_,a,b in nearby(pp):
        if a['glyph_index'] not in active and b['glyph_index'] not in active:continue
        k=pairkey(a,b,s.font.face.upem)
        if any(o.overlap(k,p/16) for o in oracles for p in range(16)):
            return changes,dict(applied=False,reason='microspacing raster veto',before_energy=start_score[0])
    result={i:(g['x']-origin[i]['x'],g['y']-origin[i]['y']) for i,g in enumerate(current) if (g['x'],g['y'])!=(origin[i]['x'],origin[i]['y'])}
    return result,dict(applied=True,before_energy=start_score[0],after_energy=best_score[0],
        before_clearances=start_score[1],after_clearances=best_score[1],pair_targets=[v[2] for v in pairs],
        max_extra_dx=max(abs(g['x']-hard[i]['x']) for i,g in enumerate(current)),
        max_extra_dy=max(abs(g['y']-hard[i]['y']) for i,g in enumerate(current)),
        base_and_advance_changes=0,quantum_native=8,bound_native=32,
        meaning='Contour/counterspace proxy improvement; perceptual comfort remains subject to visual review.')
