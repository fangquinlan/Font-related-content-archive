"""Classify the saved Maagarim hits, compare original SBL, and build a proof."""
from collections import Counter
import hashlib
import html
import json
from pathlib import Path
import unicodedata as ud

import freetype
import numpy as np
from fontTools.pens.svgPathPen import SVGPathPen

from audit_maagarim_sbl import ComponentShaper, FONT, OUT, ROOT, dump, signature
from validate_quantity_marks_v6a import GlyphRaster

SIZES = [14, 18, 24, 32, 48, 72]
PHASES = [0, .25, .5, .75]
LABELS = dict(rafe_holam='Rafe 与 holam', adjacent='相邻字母／附标',
              stacked='同一字母叠加元音／重复附标', editorial='标点／校勘记号及其附标')


def classify(text):
    # These are diagnostic categories, not judgments about the intended reading.
    for cluster in __import__('re').findall(r'[^\u0591-\u05c7][\u0591-\u05c7]*', text):
        vowels = [c for c in cluster[1:] if '\u05b0' <= c <= '\u05bb']
        if len(vowels) > 1:
            return 'stacked'
    if text in ('יעוֵֽת', 'מִדְיֶוֶת4)'):
        return 'adjacent'
    if text in ("לֹ!א!", "()[זו]ֹ", "ל?כ?ֿוֹנַנָה.,", "קָ?דָ?ֿשִׁים",
                "יוֹיָ(?כ?)[רִ]י()[ב]ֿ", "אֱלֹ'יִם", "שְמ[וׁׂ]עַ(ו)",
                "[וַתֹּאמַרְןָ]", "(וָואי/וָואדע-", "()[ַעֲ]בֹר"):
        return 'editorial'
    assert '\u05bf' in text and '\u05b9' in text, text
    return 'rafe_holam'


class ComponentRaster(GlyphRaster):
    def pair_pixels(self, glyphs, collision, phase):
        pieces = []
        scale = self.size / self.shaper.font.face.upem
        for i in (collision['i'], collision['j']):
            g = glyphs[i]
            x, y = g['x']*scale+phase, g['y']*scale
            ix, iy = int(np.floor(x)), int(np.floor(y))
            a, left, top = self.mask(self.shaper.tt.getGlyphID(g['name']), x-ix, y-iy)
            pieces.append((left+ix, -top-iy, a))
        (ax, ay, a), (bx, by, b) = pieces
        x0, y0 = max(ax, bx), max(ay, by)
        x1, y1 = min(ax+a.shape[1], bx+b.shape[1]), min(ay+a.shape[0], by+b.shape[0])
        if x0 >= x1 or y0 >= y1:
            return 0
        aa = a[y0-ay:y1-ay, x0-ax:x1-ax]
        bb = b[y0-by:y1-by, x0-bx:x1-bx]
        return int(np.sum((aa > 153) & (bb > 153)))


def pair_id(c):
    return tuple(sorted(zip(c['clusters'], c['names'])))


def outline_svg(s, text):
    gs = s.expand(s.shape(text))
    hits = s.mark_collisions(gs)
    involved = {i for c in hits for i in (c['i'], c['j'])}
    paths = []
    boxes = []
    for i, g in enumerate(gs):
        if not g['box']:
            continue
        x0, y0, x1, y1 = g['box']
        boxes.append((x0+g['x'], y0+g['y'], x1+g['x'], y1+g['y']))
        pen = SVGPathPen(s.gs)
        s.gs[g['name']].draw(pen)
        color = '#d04032' if g['mark'] and i in involved else '#235d9f' if i in involved else '#3d4248'
        paths.append(f'<path fill="{color}" d="{pen.getCommands()}" transform="translate({g["x"]} {g["y"]})"/>')
    x0 = min(b[0] for b in boxes)-100
    y0 = min(b[1] for b in boxes)-100
    x1 = max(b[2] for b in boxes)+100
    y1 = max(b[3] for b in boxes)+100
    return f'<svg class="outline" role="img" aria-label="附标碰撞轮廓示意" viewBox="{x0} {-y1} {x1-x0} {y1-y0}"><g transform="scale(1 -1)">'+''.join(paths)+'</g></svg>'


def main():
    summary = json.loads((OUT/'scan-summary.json').read_text(encoding='utf-8'))
    rows = json.loads((OUT/'colliding-fragments.json').read_text(encoding='utf-8'))
    lines = [json.loads(x) for x in (OUT/'colliding-lines.jsonl').read_text(encoding='utf-8').splitlines()]
    s = ComponentShaper(FONT)
    original = ComponentShaper(ROOT/'SBL_BLit.ttf')
    previous = ComponentShaper(ROOT/'output/v5.4/SBL_BLit-v5.4.ttf')
    rasters = {size:ComponentRaster(s, size) for size in SIZES}
    comparisons, newly_introduced = [], []
    all_hits = {}
    for line in lines:
        t = line['text']
        current = s.shape(t)
        assert signature(previous.shape(t)) == signature(current)
        gs = s.expand(current)
        hits = s.mark_collisions(gs)
        old_hits = original.mark_collisions(original.expand(original.shape(t)))
        old_map = {pair_id(c):c for c in old_hits}
        for c in hits:
            prior = old_map.get(pair_id(c))
            entry = dict(jsonl_line=line['jsonl_line'], text_line=line['text_line'],
                         pair=pair_id(c), original_area=prior['area'] if prior else 0,
                         v6_area=c['area'])
            comparisons.append(entry)
            if not prior:
                newly_introduced.append(entry)
        for c in line['collisions']:
            metrics = {str(size):[rasters[size].pair_pixels(gs, c, p) for p in PHASES] for size in SIZES}
            all_hits.setdefault(c['fragment'], []).append(dict(c, raster_dark_pixels=metrics))
    category_counts = Counter()
    category_occurrences = Counter()
    raster_stats = Counter()
    for i, r in enumerate(rows, 1):
        text = r['text']
        r['id'] = i
        r['category'] = classify(text)
        category_counts[r['category']] += 1
        category_occurrences[r['category']] += r['colliding_occurrences']
        r['codepoints'] = [f'U+{ord(c):04X}' for c in text]
        r['hits'] = all_hits[text]
        r['max_dark_pixels'] = {str(size):max(max(c['raster_dark_pixels'][str(size)]) for c in r['hits']) for size in SIZES}
        r['body_dark_overlap'] = any(r['max_dark_pixels'][str(size)] for size in (18,24))
        raster_stats['body_dark_overlap_types'] += bool(r['body_dark_overlap'])
        raster_stats['no_body_dark_overlap_types'] += not r['body_dark_overlap']
        for size in SIZES:
            raster_stats[f'dark_overlap_{size}px_types'] += bool(r['max_dark_pixels'][str(size)])
        local_hits = s.mark_collisions(s.expand(s.shape(text)))
        assert Counter((' / '.join(sorted(c['names'])),round(c['area'],2)) for c in local_hits) == Counter(
            (' / '.join(sorted(c['names'])),round(c['area'],2)) for c in r['hits'][:len(local_hits)])
    evidence = dict(categories={k:dict(label=LABELS[k], types=category_counts[k], occurrences=category_occurrences[k]) for k in LABELS},
                    colliding_token_occurrences=sum(r['colliding_occurrences'] for r in rows),
                    all_current_hit_pairs_already_present_in_original=not newly_introduced,
                    v54_geometry_equal_for_all_positive_lines=True,
                    original_comparisons=comparisons, newly_introduced=newly_introduced,
                    raster=dict(sizes=SIZES, phases=PHASES, coverage_threshold='Both glyph coverages > 153/255',
                                scope='Every vector hit, at its actual full-line positions, using individual mark/base component masks. Component hinting can differ from a parent composite; real-browser proof also provided. Raster screening of vector hits only, not an exhaustive search for raster-only contacts.',
                                summary=dict(raster_stats)),
                    fragments=rows)
    dump(OUT/'review.json', evidence)
    build_proof(summary, evidence, s)
    build_report(summary, evidence)
    print(json.dumps({k:v for k,v in evidence.items() if k not in ('fragments','original_comparisons')}, ensure_ascii=False, indent=2))


def build_proof(summary, evidence, s):
    esc = html.escape
    rows = sorted(evidence['fragments'], key=lambda r: (list(LABELS).index(r['category']), not r['body_dark_overlap'], -r['max_area']))
    cards = []
    for r in rows:
        e = r['examples'][0]
        sizes = ''.join(f'<div class="sample"><small>{px} px</small><span class="he v6" dir="rtl" lang="he" style="font-size:{px}px">{esc(r["text"])}</span></div>' for px in (18,24,48))
        old = f'<div class="sample"><small>原始 SBL · 48 px</small><span class="he original" dir="rtl" lang="he" style="font-size:48px">{esc(r["text"])}</span></div>'
        source_lines = ''.join(f'<p class="source-label">JSONL {x["jsonl_line"]} 行 · 作品 {x["misyzira"]} · 正文 {x["text_line"]} 行 · {esc(x["title"])}</p><p class="context he v6" lang="he" dir="rtl">{esc(x["line"])}</p>' for x in r['examples'])
        body = '18–24 px 筛查有深色像素重叠' if r['body_dark_overlap'] else '18–24 px 未检出深色像素重叠'
        cards.append(f'''<article data-category="{r['category']}" id="case-{r['id']}">
<div class="case-head"><h2>#{r['id']} · {LABELS[r['category']]}</h2><span>{r['colliding_occurrences']} 处 · {body}</span></div>
<div class="columns"><div>{sizes}{old}</div><div><small>轮廓示意：涉及碰撞的附标为红色，对侧轮廓为蓝色</small>{outline_svg(s,r['text'])}</div></div>
<details><summary>原文与定位、Unicode 序列</summary>{source_lines}<p class="code">{' '.join(r['codepoints'])}</p><p>最大交叠面积 {r['max_area']:.2f} 字体单位²；UPEM 2048。附标与字母逐一求交，不把整个字符簇合并后跳过。</p></details></article>''')
    options = '<option value="all">全部 31 种片段</option>'+''.join(f'<option value="{k}">{LABELS[k]} · {v["types"]}</option>' for k,v in evidence['categories'].items())
    page = '''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>SBL V6 · Maagarim 附标检查</title>
<style>
@font-face{font-family:SBLV6;src:url('../output/v6/SBL_BLit-v6.ttf?sha=HASH') format('truetype');font-weight:400;font-style:normal}
@font-face{font-family:SBLOriginal;src:url('../SBL_BLit.ttf') format('truetype');font-weight:400;font-style:normal}
*{box-sizing:border-box}body{margin:0;background:#f4f3ef;color:#222c34;font:15px/1.65 system-ui,'Microsoft YaHei',sans-serif}main{max-width:1200px;margin:auto;padding:36px 30px}h1{font-size:30px;line-height:1.3;margin:0 0 12px}h2{font-size:17px;margin:0}.lede{max-width:960px}.stats{display:flex;gap:28px;flex-wrap:wrap;margin:22px 0}.stats strong{display:block;font-size:28px}.stats small{color:#65717b}nav{display:flex;gap:18px;align-items:center;flex-wrap:wrap;margin:22px 0}select{font:inherit;padding:8px 12px;border:1px solid #b6c0c5;border-radius:6px}a{color:#255b86}article{border:1px solid #d9dedf;background:white;padding:22px;margin:18px 0;border-radius:9px}.case-head{display:flex;justify-content:space-between;gap:14px;flex-wrap:wrap}.case-head span{font-size:12px;color:#65717b}.columns{display:grid;grid-template-columns:1fr 1fr;gap:35px;margin:18px 0}.sample{display:flex;align-items:center;justify-content:space-between;gap:22px;min-height:60px}.sample small{font:12px system-ui;color:#65717b}.he{font-synthesis:none;font-weight:400;font-style:normal;font-kerning:normal;letter-spacing:0}.v6{font-family:SBLV6}.original{font-family:SBLOriginal}.outline{width:100%;height:180px;display:block;margin-top:10px}.context{font-size:24px;line-height:2.1;white-space:pre-wrap}.source-label{font:13px system-ui;color:#556876}.code{overflow-wrap:anywhere;font:12px/1.8 monospace}details{border-top:1px solid #edf0f1;padding-top:12px}summary{cursor:pointer;color:#41637a}.notice{font-size:13px;color:#65717b}article[hidden]{display:none}@media(max-width:750px){main{padding:24px 15px}.columns{grid-template-columns:1fr}.case-head{display:block}}
</style><main>
<h1>SBL V6 · Maagarim 附标检查</h1>
<p class="lede">全量扫描 8,243 篇正文的 122,767 个含附标行，保留原文顺序、空格与校勘记号。发现的碰撞都能在原始 SBL 中复现；下面按实际源文片段列出。</p>
<div class="stats"><div><strong>219,072</strong><small>不同含附标词形／符号串</small></div><div><strong>31</strong><small>碰撞片段类型</small></div><div><strong>33</strong><small>片段出现处，分布于 32 行</small></div><div><strong>36</strong><small>轮廓相交对</small></div></div>
<p class="notice">轮廓相交不一定在正文大小下明显。像素筛查使用 6 个字号、4 个水平相位；不修改源文，不删除重复附标。字体仍为已交付的 V6。</p>
<nav><label>查看 <select id="filter">OPTIONS</select></label><a href="../reports/sbl-v6-maagarim/审查报告.md">完整报告</a><a href="../reports/sbl-v6-maagarim/review.json">逐项数据</a><span id="loaded">字体加载中…</span></nav>
CARDS</main><script>
document.querySelector('#filter').addEventListener('change',e=>{document.querySelectorAll('article').forEach(x=>x.hidden=e.target.value!=='all'&&x.dataset.category!==e.target.value)});
document.fonts.ready.then(()=>{document.querySelector('#loaded').textContent=document.fonts.check('24px SBLV6')&&document.fonts.check('24px SBLOriginal')?'两款字体已加载':'字体加载失败'});
</script></html>'''
    page = page.replace('HASH',summary['font_sha256']).replace('OPTIONS',options).replace('CARDS','\n'.join(cards))
    (ROOT/'proof/maagarim-sbl-v6.html').write_text(page, encoding='utf-8')


def build_report(summary, e):
    lines = ['# SBL V6 · Maagarim 希伯来文附标审查', '',
        '结论：有残余碰撞。全量正文扫描得到 **31 种片段、33 处出现、32 个原文行、36 对轮廓相交**。这些碰撞对全部能在原始 SBL 中复现；本次没有修改字体或语料。', '',
        '## 范围与方法', '',
        f'- 源文件：`{summary["source"]}`；SHA-256 `{summary["source_sha256"]}`。',
        f'- 字体：`output/v6/SBL_BLit-v6.ttf`（SBL Local Optical V6）；SHA-256 `{summary["font_sha256"]}`。',
        '- 8,243 篇，123,908,433 字符；557,435 个含附标词形／符号串，去重后 219,072 种。',
        '- 检查 JSONL 的 `text` 正文字段。`yezira` 是同一文本的 HTML 表示，不与正文重复拼接；作者、标题等元数据不算正文。',
        '- 每个含附标的原文行完整排版，共 122,767 行、10,879,826 字符，最长 840 字符；保留空格、词界、校勘符号、控制字符及附标次序。扫描所有含附标行，而非高频抽样。',
        '- HarfBuzz 默认 Hebrew/RTL/`he` 排版；逐条 Bézier 轮廓求交，面积阈值 0.5 字体单位²，UPEM 2048。检查同簇附标，也拆开 GSUB 复合字形中嵌入的 shin/sin dot、dagesh、holam，不因其已合成字形而漏检。',
        '- 49,884 行原文与 NFD 文本不同，但排版几何全部一致；其他 72,883 行本身即为 NFD。未检出缺字、跨空白词界的附标碰撞，未检出复合字形内部组件碰撞。',
        '- 阳性原文行与 V5.4 排版几何完全相同；36 对当前碰撞均在原始 SBL 中已存在。原始 SBL 对照只针对本次阳性，不代表对原始字体全库碰撞总数的统计。', '',
        '## 分类', '', '| 类别 | 片段类型 | 出现处 |', '|---|---:|---:|']
    for v in e['categories'].values():
        lines.append(f'| {v["label"]} | {v["types"]} | {v["occurrences"]} |')
    lines += ['', '“叠加元音／重复附标”仅描述字符序列，不擅自判定为转录错误。部分资料可能表达异读；不可通过删除或改序来静默修复。“校勘记号”类也可能包含应由字体处理的标点避让。', '',
        '## 正文大小与视觉复核', '',
        f'- 对每一对轮廓阳性，在完整源行原有坐标上用 FreeType 检查 14、18、24、32、48、72 px，水平相位 0、¼、½、¾ px。两者覆盖率都大于 60% 才计为深色像素重叠。',
        f'- 18–24 px 至少一个相位有深色重叠：**{e["raster"]["summary"]["body_dark_overlap_types"]} 种**；未检出该阈值重叠：**{e["raster"]["summary"]["no_body_dark_overlap_types"]} 种**。后者仍有数学轮廓相交，不等于保证所有屏幕下视觉无碰撞。',
        '- 屏幕渲染器、hinting、DPI、行内相位会改变细节；组件栅格化也可能与复合字形整体 hinting 略异。浏览器样张使用完整字体实际排版，另附矢量着色示意。',
        '- 此像素检查针对轮廓阳性，不是对所有无轮廓交叠的词形额外穷举光栅接触。未检查行距造成的跨行碰撞，混合方向段落的完整 Unicode 双向重排也不属于 HarfBuzz 单行 RTL 扫描；阳性含标点案例可在样张中展开原文复核。', '',
        '优先值得处理的字体层面问题是 rafe–holam 避让，以及 `יעוֵֽת` 的 tsere 与前一个 ayin 接触。双元音、重复附标及附着在校勘括号／问号上的标记，需要保留其原文语义后再决定如何显示。', '',
        '## 全部阳性', '', '| # | 原文片段 | 类别 | 出现处 | 18–24 px 深色重叠 | 作品编号／正文行 |', '|---:|---|---|---:|---|---|']
    for r in e['fragments']:
        ex = r['examples'][0]
        lines.append(f'| {r["id"]} | <bdi dir="rtl">{html.escape(r["text"])}</bdi> | {LABELS[r["category"]]} | {r["colliding_occurrences"]} | {"有" if r["body_dark_overlap"] else "未检出"} | {ex["misyzira"]} / {ex["text_line"]} |')
    lines += ['', '## 可复现文件', '',
        '- `scripts/audit_maagarim_sbl.py`：全量原文、NFD、组件轮廓扫描。',
        '- `scripts/report_maagarim_sbl.py`：原始字体对照、光栅复核、样张和报告生成。',
        '- `reports/sbl-v6-maagarim/colliding-lines.jsonl`：32 个阳性行的完整正文、JSONL 行号、作品编号、正文行号和字符偏移。',
        '- `reports/sbl-v6-maagarim/review.json`：逐项 Unicode 序列、相交面积、像素筛查、对照数据。',
        '- `proof/maagarim-sbl-v6.html`：可按类别筛选的 31 项实际字体样张。', '']
    browser_path = OUT/'browser-validation.json'
    if browser_path.exists():
        browser = json.loads(browser_path.read_text(encoding='utf-8'))
        lines += ['## 浏览器验证记录', '',
                  f'- Chrome 实际加载本地 SBL V6 与原始 SBL，响应字体 SHA-256 与被扫描字体一致；未启用合成粗体／斜体。',
                  f'- 31 种片段及其保存的源行示例，在 18、24、48 px 共 {browser["pixelNormalizationChecks"]} 次原文／NFD 像素比较，差异 {len(browser["pixelNormalizationFailures"])} 次。',
                  '- 视觉复核包含 rafe–holam 粘连、`יעוֵֽת` 的 tsere–ayin 接触，以及问号与其后 rafe／相邻 holam 的交叠。',
                  f'- 浏览器 `{browser["userAgent"]}`，设备像素比 {browser["dpr"]}；详情见 `browser-validation.json`。', '']
    (OUT/'审查报告.md').write_text('\n'.join(lines),encoding='utf-8')


if __name__ == '__main__':
    main()
