"""Bounded multi-level fallback for overfull, uninterpreted source notation.

Ordinary Hebrew has no inferred multi-vowel reading here. Every encoded mark
is retained, below its original host, with the original left/right relations.
Only explicitly listed overfull clusters may use extra lower levels. Neither
line metrics nor glyph shapes nor base spacing is changed. Deep exceptional
notation needs enough line leading; its ink bounds are recorded for proofing.
"""
from concurrent.futures import ProcessPoolExecutor,as_completed
import copy,json
import build_sbl_review_v6e as b
from build_sbl_review_v6e import *
from audit_dictionaries_v6b import mark_owners

def fallback(r):
    s=b.s;gs=s.shape(r['text']);parts=s.expand(gs)
    cls=sorted({parts[h[k]]['cl'] for h in s.mark_collisions(parts)+layout_issues(parts,r['text']) for k in ('i','j') if parts[h[k]]['mark']})
    changes={};steps=[]
    for cl in cls:
        delta=None
        for levels in ([0,-512],[0,-512,-1024],[0,-512,-1024,-1536]):
            try:
                delta,detail=solve(s,r['text'],b.rasters,max_dx=1024,only_clusters={cl},initial=changes,
                    annotation_layers=levels,first_feasible=True)
            except TimeoutError as e:delta=None;detail=dict(reason=str(e))
            steps.append(dict(cluster=cl,levels=levels,detail=detail))
            if delta is not None:break
        if delta is None:return dict(**r,fallback_attempts=steps)
        for i,(dx,dy) in delta.items():
            ox,oy=changes.get(i,(0,0));changes[i]=(ox+dx,oy+dy)
    pp=s.expand([shifted(g,*changes.get(i,(0,0))) for i,g in enumerate(gs)])
    if s.mark_collisions(pp) or layout_issues(pp,r['text']):return dict(**r,fallback_attempts=steps)
    after=dict(r);after.update(changes=changes,details=dict(method='explicit_overfull_annotation_levels',
        ordinary_hebrew_claim=False,steps=steps,base_and_advance_changes=0,
        minimum_ink_y=min(p['y']+p['box'][1] for p in pp if p['box']),
        maximum_ink_y=max(p['y']+p['box'][3] for p in pp if p['box']),
        layered_glyphs=[i for i,xy in changes.items() if xy[1]<0],
        note='Uninterpreted source notation, kept visible; extra leading may be necessary.'))
    return after

def main():
    cache=OUT/'solutions.json';d=read(cache)
    good={r['text']:r for r in d['rows']};failed=[]
    with ProcessPoolExecutor(max_workers=3,initializer=b.init) as pool:
        fs=[pool.submit(fallback,r) for r in d['failed']]
        for n,f in enumerate(as_completed(fs),1):
            r=f.result()
            if r['changes'] is None:failed.append(r)
            else:good[r['text']]=r
            dump(OUT/'fallback-solutions.json',dict(rows=list(good.values()),failed=failed))
            print('FALLBACK',n,len(fs),repr(r['text']),r['changes'],r.get('details'),flush=True)
    if not failed:
        d.update(rows=list(good.values()),failed=[]);dump(cache,d)
    print('DONE',len(good),'remaining',len(failed),flush=True)
if __name__=='__main__':main()
