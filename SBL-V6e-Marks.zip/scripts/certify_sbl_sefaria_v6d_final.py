"""Certify the final zero guard against the completed full-scan candidate.

Prove the compiled semantic delta is one zero-position context containing
quotesingle; GSUB never mentions that glyph and cmap maps only U+0027 to it.
Consequently a run without U+0027 cannot match the guard. Every run that can
possibly match is reshaped with both binaries, raw and NFD. This is a static
non-interference proof plus exhaustive testing, not a sample-based shortcut.
"""
from collections import Counter,defaultdict
import argparse,copy,sqlite3,time
from validate_sbl_sefaria_v6d import *
REF=OUT/'pass1'

def semantics(f):
    g=f['GPOS'].table;out=defaultdict(list)
    for ext in g.LookupList.Lookup[-1].SubTable:
        st=ext.ExtSubTable
        assert st.Format==1
        for name,rs in zip(st.Coverage.glyphs,st.ChainPosRuleSet):
            for rule in rs.ChainPosRule:
                assert rule.InputGlyphCount==1 and rule.PosCount==1
                rec=rule.PosLookupRecord[0];assert rec.SequenceIndex==0
                vals=[]
                for action in g.LookupList.Lookup[rec.LookupListIndex].SubTable:
                    sub=action.ExtSubTable
                    if name not in sub.Coverage.glyphs:continue
                    val=sub.Value if sub.Format==1 else sub.Value[sub.Coverage.glyphs.index(name)]
                    vals.append(tuple(getattr(val,k,0) or 0 for k in ['XPlacement','YPlacement','XAdvance','YAdvance']))
                assert len(vals)==1
                out[name].append((tuple(rule.Backtrack),tuple(rule.LookAhead),vals[0]))
    return dict(out)

def proof():
    a,b=TTFont(REF/'font.ttf'),TTFont(DEST)
    for tag in a.reader.keys():
        if tag not in ('GPOS','head','name'):assert a.reader[tag]==b.reader[tag]
    # Existing complete V6c lookups are unchanged; validate the appended
    # action/context encoding by semantics because new action IDs renumber.
    count=read(OUT/'build.json')['export']['existing_lookup_count']
    assert all(xml(a,a['GPOS'].table.LookupList.Lookup[i])==xml(b,b['GPOS'].table.LookupList.Lookup[i]) for i in range(count))
    x,y=semantics(a),semantics(b);added=[]
    for n in set(x)|set(y):
        remaining=list(y.get(n,[]))
        for r in x.get(n,[]):assert r in remaining;remaining.remove(r)
        added.extend((n,*r) for r in remaining)
        assert [r for r in y.get(n,[]) if r not in remaining]==x.get(n,[])
    assert len(added)==1 and added[0][-1]==(0,0,0,0),added
    assert 'quotesingle' in [added[0][0],*added[0][1],*added[0][2]]
    assert b'quotesingle' not in xml(b,b['GSUB'].table)
    aliases={cp for table in b['cmap'].tables if table.isUnicode() for cp,n in table.cmap.items() if n=='quotesingle'}
    assert aliases=={0x27},aliases
    return dict(reference_sha256=sha(REF/'font.ttf'),font_sha256=sha(DEST),
        compiled_semantic_delta=added,cmap_quotesingle_aliases=['U+0027'],gsub_mentions_quotesingle=False,
        other_outline_metric_hinting_tables_identical=True,
        necessary_condition='The run must contain U+0027; otherwise the only new zero guard cannot match.')

def certify(scope,shard=0,workers=3):
    start=time.time();p=proof();c=Check();a,b=font(REF/'font.ttf'),font(DEST)
    stats=Counter();differences=[];errors=[];checked=0;static=0
    if scope=='sefaria':
        prefix=f'sefaria-{shard}';old=read(REF/f'{prefix}-complete.json')
        db=sqlite3.connect(DB.as_uri()+'?mode=ro',uri=True)
        iterable=(dict(id=i,text=t,count=count) for i,t,count in db.execute('select id,text,count from runs where id % ?=? order by id',(workers,shard)))
        payloads={k:{r['id']:r for r in rows(REF/f'{prefix}-{k}.jsonl')} for k in ['collisions','raster','regressions','changed','normalization']}
    else:
        prefix=scope;old=read(REF/f'{scope}-validation.json');iterable=all_records(scope)
    assert old['font_sha256']==p['reference_sha256']
    for n,r in enumerate(iterable,1):
        t=r['text'];nf=ud.normalize('NFD',t);stats['runs']+=1
        if "'" not in t and "'" not in nf:static+=1;continue
        checked+=1
        aa,bb=shape(a,t),shape(b,t);an,bn=shape(a,nf),shape(b,nf)
        if aa!=bb or an!=bn:
            out=c.inspect(t,True);differences.append(dict(**r,**out))
            if any(out[k] for k in ('collisions','raster','identity','layout')):errors.append(dict(**r,**out))
            if stream_geom(bb)!=stream_geom(bn):errors.append(dict(**r,reason='changed_NFD_geometry'))
            if scope=='sefaria':
                # The protected context was collision-free in the reference.
                assert r['id'] not in payloads['collisions'] and r['id'] not in payloads['raster']
                if out['moved_glyphs']:payloads['changed'][r['id']]=dict(**r,moved_glyphs=out['moved_glyphs'])
                else:payloads['changed'].pop(r['id'],None)
        if checked%5000==0:print('FINAL',prefix,'reshaped',checked,'unaffected',static,'changed',len(differences),'seconds',round(time.time()-start),flush=True)
    assert stats['runs']==old['statistics']['runs'] and not errors,(scope,errors[:1])
    certification=dict(**p,scope=prefix,all_runs=stats['runs'],exhaustively_reshaped_raw_and_nfd=checked,
        statically_proved_unaffected=static,changed_vs_full_scan_reference=len(differences),failures=errors,
        reference_report_sha256=sha(REF/(f'{prefix}-complete.json' if scope=='sefaria' else f'{scope}-validation.json')),
        seconds=round(time.time()-start,1))
    dump(OUT/f'{prefix}-final-certification.json',certification)
    final=copy.deepcopy(old);final['font_sha256']=sha(DEST);final['final_binary_certification']=certification
    if scope=='sefaria':
        original_changed={r['id']:r for r in rows(REF/f'{prefix}-changed.jsonl')}
        moved_delta=sum(r['moved_glyphs'] for r in payloads['changed'].values())-sum(r['moved_glyphs'] for r in original_changed.values())
        delta=len(payloads['changed'])-len(original_changed)
        final['statistics']['changed_runs']+=delta;final['statistics']['identical_runs']-=delta;final['statistics']['moved_glyphs']+=moved_delta
        for name,rs in payloads.items():
            with (OUT/f'{prefix}-{name}.jsonl').open('w',encoding='utf8') as f:
                for _,v in sorted(rs.items()):f.write(json.dumps(v,ensure_ascii=False)+'\n')
        final['tables']=tables();dump(OUT/f'{prefix}-complete.json',final)
    else:
        # The only reference-to-final change restores the prior V6c geometry.
        changed=[]
        basefont=font(BASE)
        for r in old.get('changed',[]):
            if shape(basefont,r['text'])!=shape(b,r['text']):changed.append(r)
        prior_changes=len(old.get('changed',[]));final['changed']=changed
        final['statistics']['changed_runs']=len(changed)
        final['statistics']['identical_runs']=final['statistics']['runs']-len(changed)
        if not changed:final['statistics']['moved_glyphs']=0
        final['tables']=tables();dump(OUT/f'{scope}-validation.json',final)
    print('CERTIFIED',prefix,'runs',stats['runs'],'reshaped',checked,'changed',len(differences),flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('scope',choices=['sefaria','prior']);p.add_argument('--shard',type=int,default=0);args=p.parse_args()
    if args.scope=='sefaria':certify('sefaria',args.shard)
    else:
        for scope in ['merged','bibles','dictionaries','maagarim']:certify(scope)
        import regression_sbl_dictionaries_v6b as g
        g.PARENT=BASE;g.DEST=DEST;g.REPORT=OUT;g.main()
