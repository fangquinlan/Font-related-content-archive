"""Independent HarfBuzz spot replay accompanying the exact packing proof."""
import sqlite3,unicodedata as ud
from build_sbl_review_v6e import *
from certify_sbl_v6c_final import font,shape

def main():
    proof=read(OUT/'packing-proof.json');packed=OUT/'SBL_BLit-v6e-packed.ttf'
    assert sha(DEST)==proof['reference_sha256'] and sha(packed)==proof['font_sha256']
    a,b=font(DEST),font(packed);cases={r['text'] for r in read(OUT/'build.json')['desired']}
    cases.update(r['text'] for r in rows(PRIOR/'residual-pairs.jsonl') if r['classification']=='review')
    comparisons=0
    for t in cases:
        for v in [t,ud.normalize('NFD',t)]:
            assert shape(a,v)==shape(b,v),(t,v)
            comparisons+=1
    dump(OUT/'packing-render-validation.json',dict(reference_sha256=sha(DEST),font_sha256=sha(packed),
        distinct_fragments_and_full_runs=len(cases),raw_nfd_stream_comparisons=comparisons,differences=0,
        proof_report_sha256=sha(OUT/'packing-proof.json')))
    print('PACKING REPLAY',len(cases),comparisons,'differences 0',flush=True)
if __name__=='__main__':main()
