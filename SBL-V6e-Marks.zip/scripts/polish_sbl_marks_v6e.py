"""Cache optical refinement independently of collision fitting."""
from concurrent.futures import ProcessPoolExecutor,as_completed
import copy,json
import build_sbl_review_v6e as b
from build_sbl_review_v6e import *
from optical_marks_v6e import refine

def polish(r):
    s=b.s;hard={int(i):tuple(xy) for i,xy in r['changes'].items()}
    active={i for i,g in enumerate(s.shape(r['text'])) if g['mark']} if r.get('optical_only') else None
    changes,detail=refine(s,r['text'],hard,active)
    out=copy.deepcopy(r);out.update(changes=changes,collision_solution=hard,optical=detail)
    gs=[shifted(g,*changes.get(i,(0,0))) for i,g in enumerate(s.shape(r['text']))]
    out['ink_bounds']=[min(g['y']+g['box'][1] for g in gs if g['box']),max(g['y']+g['box'][3] for g in gs if g['box'])]
    return out

def main():
    data=read(OUT/'solutions.json');assert not data['failed']
    wanted={r['text']:r for r in data['rows']}
    s=ComponentShaper(BASE)
    for r in read(PRIOR/'build.json')['desired']:
        t=r['text']
        if t in wanted or r['details'].get('method')=='zero guard':continue
        # Previous ordinary repairs provide already collision-free examples.
        wanted[t]=dict(text=t,names=[g['name'] for g in s.shape(t,preserve=True)],changes={},
            details=dict(method='optical-only on previously clear notation'),optical_only=True,
            evidence=r.get('evidence',[]),guard_zero=True)
    cache=OUT/'optical-solutions.json';saved=read(cache) if cache.exists() else {}
    data={r['text']:r for r in saved.get('rows',[])}
    with ProcessPoolExecutor(max_workers=3,initializer=b.init) as pool:
        fs=[pool.submit(polish,r) for t,r in wanted.items() if t not in data]
        for n,f in enumerate(as_completed(fs),1):
            r=f.result();data[r['text']]=r
            dump(cache,dict(parent_sha256=sha(BASE),model='mark-counterspace-1',rows=list(data.values())))
            print('OPTICAL',n,len(fs),repr(r['text']),r['optical'],flush=True)
    result=b.compile_font(sorted(data.values(),key=lambda r:r['text']));dump(OUT/'build.json',result)
    print('BUILT',sha(DEST),result['export'],flush=True)
if __name__=='__main__':main()
