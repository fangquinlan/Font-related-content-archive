"""Read-only validation of the local Sefaria import and its source versions."""
import base64,hashlib,time
from pathlib import Path
from build_sbl_review_v6e import ROOT,OUT,read,rows,dump,sha

def main():
    start=time.time();source=Path(r'D:\sefaria');manifest=source/'metadata/download_manifest.jsonl'
    refs=rows(manifest)
    # The download manifest also lists schemas, CSV links and export metadata;
    # compare the same text-version directory that the corpus importer reads.
    expected={r['local_path']:r for r in refs if r['local_path'].startswith('json/') and r['local_path'].endswith('.json')}
    actual={p.relative_to(source).as_posix():p for p in (source/'json').rglob('*.json')}
    differences=sorted(set(expected)^set(actual));errors=[];total=0
    for n,(name,p) in enumerate(actual.items(),1):
        r=expected.get(name);size=p.stat().st_size;total+=size
        if not r:continue
        with p.open('rb') as f:md5=base64.b64encode(hashlib.file_digest(f,'md5').digest()).decode('ascii')
        if size!=int(r['size']) or md5!=r['md5Hash']:errors.append(name)
        if n%3000==0:print('INPUT',n,'errors',len(errors),flush=True)
    m=read(ROOT/'data/sefaria-v6c/manifest.json');dbsha=sha(ROOT/'data/sefaria-v6c/runs.sqlite3');msha=sha(manifest)
    assert dbsha==m['database_sha256'] and msha==m['input_manifest_sha256']
    result=dict(current_json_files=len(actual),bytes=total,input_manifest_sha256=msha,database_sha256=dbsha,
        added_or_missing_files=differences,size_or_md5_failures=errors,source_rewritten=False,
        scope='All json/ text-version files; schemas/link CSV/export metadata are not text corpora.',
        non_text_manifest_entries=len(refs)-len(expected),seconds=round(time.time()-start,1))
    dump(OUT/'input-validation.json',result);print('INPUT DONE',len(actual),'errors',len(errors),flush=True)
if __name__=='__main__':main()
