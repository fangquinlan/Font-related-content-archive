"""Rebuild the release from its retained controls, then pack it losslessly.

The documented bounded search can be rerun separately. Exact binary replay
uses recorded desired positions and attachment-compensated actions, avoiding
machine-time-dependent branch-and-bound stopping points.
"""
import argparse,copy
from build_sbl_review_v6e import *
from pack_sbl_review_v6e import main as pack

def main(folder):
    folder.mkdir(parents=True,exist_ok=True);build=read(OUT/'build.json');controls=copy.deepcopy(build['controls'])
    for r in controls:r['changes']={int(i):v for i,v in r['changes'].items()}
    unpacked=folder/'SBL_BLit-v6e-unpacked.ttf';final=folder/'SBL_BLit-v6e.ttf';meta=dict(META,report=folder)
    export([r for r in controls if not r.get('validation_only')],unpacked,base=BASE,**meta)
    proof=read(OUT/'packing-proof.json');assert sha(unpacked)==proof['reference_sha256']
    pack(unpacked,final,False);assert sha(final)==proof['font_sha256']
    d=dict(parent_sha256=sha(BASE),unpacked_sha256=sha(unpacked),font_sha256=sha(final),byte_identical=True,
        method='Replay saved compensated controls, deterministic GPOS export, lossless action packing.')
    dump(OUT/'reproducibility.json',d);print('REPRODUCED',sha(final),flush=True)
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--out',type=Path,default=ROOT/'tmp/reproduced-sbl-v6e');args=p.parse_args();main(args.out)
