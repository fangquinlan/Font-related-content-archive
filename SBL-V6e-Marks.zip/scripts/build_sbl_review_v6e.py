"""Preserve and separate unresolved source notation; add optical mark microspacing.

V6e deliberately changes V6d's eligibility: all 856 unresolved pairs are
rendering requirements. The separate 641 evidenced source errors remain
excluded. No source is rewritten and no linguistic interpretation is invented.
"""
from concurrent.futures import ProcessPoolExecutor,as_completed
from collections import defaultdict,Counter
from pathlib import Path
import argparse,copy,json,time,unicodedata as ud
from audit_maagarim_sbl import ROOT,ComponentShaper,dump
from audit_dictionaries_v6b import layout_issues,source_issues,center,code
from build_sbl_dictionaries_v6b import solve,solve_split,export,shifted,SIZES
from audit_sbl_merged_v6b import nearby,RasterOracle,pairkey
from report_maagarim_sbl import ComponentRaster
from dictionary_corpus_v6b import sha
import build_sbl_dictionaries_v6b as model

BASE=ROOT/'output/sbl-v6d/SBL_BLit-v6d.ttf'
DEST=ROOT/'output/sbl-v6e/SBL_BLit-v6e.ttf'
OUT=ROOT/'reports/sbl-v6e-review'
PRIOR=ROOT/'reports/sbl-v6d-sefaria'
META=dict(report=OUT,family='SBL Local Optical V6e',ps='SBLLocalOpticalV6e-Regular',revision=6.205,
          version_text='Version 6.205; preserved notation and optical mark spacing',unique_id='MarkSpacingV6e;SBLLocalOpticalV6e-Regular')
def read(p):return json.loads(p.read_text(encoding='utf8'))
def rows(p):return [json.loads(l) for l in p.read_text(encoding='utf8').splitlines()]

def targets():
    by=defaultdict(list)
    for r in rows(PRIOR/'residual-pairs.jsonl'):
        if r['classification']=='review':by[ud.normalize('NFD',r['fragment'])].append(r['key'])
    # Include the unresolved one-pixel contact, not only outline intersections.
    by[ud.normalize('NFD','יַגּׅ֣יד')].append('334654:raster')
    extra=OUT/'extra-targets.json'
    if extra.exists():
        for r in read(extra):by[ud.normalize('NFD',r['text'])].extend(r['evidence'])
    return [dict(text=t,evidence=e) for t,e in sorted(by.items())]

def init():
    global s,rasters,oracles
    s=ComponentShaper(BASE);rasters=[ComponentRaster(s,k) for k in SIZES];oracles=[RasterOracle(s,k) for k in SIZES]
    model.PHASES=[p/16 for p in range(16)]

def job(r):
    t=r['text'];pp=s.expand(s.shape(t));extra=[]
    for i,j,a,b in nearby(pp):
        k=pairkey(a,b,s.font.face.upem)
        if any(o.overlap(k,p/16) for o in oracles for p in range(16)):extra.append(dict(i=i,j=j))
    attempts=[];delta=None;detail={}
    for method in ['joint','neighbors','split']:
        try:
            if method=='split':delta,detail=solve_split(s,t,rasters,1024)
            else:delta,detail=solve(s,t,rasters,max_dx=1024,extra_pairs=extra,include_neighbors=method=='neighbors')
        except TimeoutError as e:delta=None;detail=dict(reason=str(e))
        attempts.append(dict(method=method,detail=detail))
        if delta is not None:break
    return dict(**r,names=[g['name'] for g in s.shape(t,preserve=True)],changes=delta,details=detail,
                attempts=attempts,source_issues=source_issues(t),guard_zero=True)

def compile_font(desired,destination=DEST):
    controls=copy.deepcopy(desired);old=ComponentShaper(BASE);history=[]
    for r in desired+controls:r['changes']={int(i):v for i,v in r['changes'].items()}
    for it in range(20):
        stat=export([r for r in controls if not r.get('validation_only')],destination,base=BASE,**META)
        new=ComponentShaper(destination);mismatch=[]
        for want,c in zip(desired,controls):
            aa,bb=old.shape(want['text']),new.shape(want['text']);assert len(aa)==len(bb)
            for i,(a,b) in enumerate(zip(aa,bb)):
                assert (a['name'],a['advance'])==(b['name'],b['advance'])
                dx,dy=want['changes'].get(i,(0,0));ex=dx-b['x']+a['x'];ey=dy-b['y']+a['y']
                if ex or ey:
                    assert a['mark'],(want['text'],a,b)
                    ox,oy=c['changes'].get(i,(0,0));c['changes'][i]=(ox+ex,oy+ey);mismatch.append((want['text'],i,ex,ey))
        history.append(len(mismatch));print('RESPONSE',it,len(mismatch),mismatch[:2],flush=True)
        if not mismatch:break
    assert history[-1]==0,history
    return dict(font_sha256=sha(destination),parent_sha256=sha(BASE),export=stat,response_history=history,desired=desired,controls=controls,
                source_text_changes=0,base_advance_changes=0)

def main(compile_only=False):
    OUT.mkdir(exist_ok=True,parents=True);DEST.parent.mkdir(exist_ok=True,parents=True)
    assert sha(BASE)=='13064cbaca49ea41bd0874675e59281d702ecf578f6c2dbf9bebd440a05d776c'
    cache=OUT/'solutions.json';saved=read(cache) if cache.exists() else {};wanted=targets()
    data={r['text']:r for r in saved.get('rows',[]) if r['changes'] is not None};failed=[]
    def save():dump(cache,dict(parent_sha256=sha(BASE),model='preserved-unresolved-1',rows=list(data.values()),failed=failed))
    if not compile_only:
        with ProcessPoolExecutor(max_workers=3,initializer=init) as pool:
            fs={pool.submit(job,r):r for r in wanted if r['text'] not in data}
            for n,f in enumerate(as_completed(fs),1):
                r=f.result()
                if r['changes'] is None:failed.append(r)
                else:data[r['text']]=r
                save();print('SOLVE',n,len(fs),repr(r['text']),r['changes'],r['details'].get('reason',''),flush=True)
    if failed or any(r['text'] not in data for r in wanted):print('UNSOLVED',len(failed),'accepted',len(data),'targets',len(wanted),flush=True);return
    result=compile_font(sorted(data.values(),key=lambda r:r['text']));dump(OUT/'build.json',result)
    print('BUILT',sha(DEST),result['export'],flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--compile-only',action='store_true');a=p.parse_args();main(a.compile_only)
