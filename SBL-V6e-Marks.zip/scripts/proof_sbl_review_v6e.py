"""Inspectable before/after specimen, with exact source notation preserved."""
import json,unicodedata as ud
from build_sbl_review_v6e import *
from report_maagarim_sbl import outline_svg

def main():
    a,b=ComponentShaper(BASE),ComponentShaper(DEST);source={r['key']:r for r in rows(PRIOR/'residual-pairs.jsonl')}
    cases=[]
    for n,r in enumerate(read(OUT/'build.json')['desired'],1):
        refs=[source[k] for k in r.get('evidence',[]) if k in source]
        raw=next((x['fragment'] for x in refs if ud.normalize('NFD',x['fragment'])==r['text']),r['text'])
        changes={int(i):v for i,v in r['changes'].items()};gs=a.shape(r['text'])
        layered=any(v[1]<0 and gs[i]['box'][3]<0 for i,v in changes.items())
        group='分层保留的复杂记号' if layered else '双点与重复附标' if any(c+c in raw for c in ['\u05c4','\u05b9','\u05b8']) else '附标光学微调' if r.get('optical_only') else '其他待考组合'
        cases.append(dict(id=n,text=raw,nfd=r['text'],group=group,layered=layered,optical=r.get('optical',{}),
            before=outline_svg(a,raw),after=outline_svg(b,raw),ink_bounds=r.get('ink_bounds'),
            refs=[dict(key=x['key'],title=x.get('title'),version=x.get('version'),pointer=x.get('example',{}).get('json_path')) for x in refs],
            codes=' '.join(f'U+{ord(c):04X}' for c in raw)))
    dump(OUT/'proof-cases.json',cases)
    t=(ROOT/'scripts/proof-sbl-v6e-template.html').read_text(encoding='utf8')
    t=t.replace('__FONT_SHA__',sha(DEST)).replace('__CASES__',json.dumps(cases,ensure_ascii=False).replace('</','<\\/'))
    (ROOT/'proof/sbl-v6e-marks.html').write_text(t,encoding='utf8');print('PROOF',len(cases),sha(DEST),flush=True)
if __name__=='__main__':main()
