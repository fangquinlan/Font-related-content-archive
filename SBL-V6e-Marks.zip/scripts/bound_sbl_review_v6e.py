"""Withdraw one optional optical refinement that crowded a preceding word.

The compiled change is proved to require hataf qamats. Every run containing
that point (raw or NFD) is reshaped; other runs cannot match either changed
context. All full-scan reports and the reference binary are retained.
"""
from collections import Counter
import argparse,copy,shutil,sqlite3,time,unicodedata as ud
import validate_sbl_review_v6e as v
from validate_sbl_review_v6e import *
from build_sbl_review_v6e import compile_font
from certify_sbl_sefaria_v6d_final import semantics
from fontTools.ttLib import TTFont
from validate_sbl_dictionaries_v6b import xml

WORD='נֳוֳרֳטֳטֳמֳיְנְנְגְפְטְ'
CANDIDATE=OUT/'bounded-unpacked.ttf'
SNAP=OUT/'boundary-reference'

def prepare():
    data=read(OUT/'optical-solutions.json');found=False
    for r in data['rows']:
        if r['text']==WORD:
            r['changes']={int(i):(0,0) for i in r['changes']};r['optical']=dict(applied=False,
                reason='Full-context boundary veto: optional motion crowded preceding final-nun hataf qamats.',previous=r['optical'])
            r['boundary_veto']=dict(run_id=117104,source_text_unchanged=True);found=True
    assert found
    result=compile_font(sorted(data['rows'],key=lambda r:r['text']),CANDIDATE)
    dump(OUT/'bounded-build.json',result);dump(OUT/'bounded-optical-solutions.json',data)
    a,b=TTFont(DEST),TTFont(CANDIDATE);old,new=semantics(a),semantics(b);delta=[]
    for glyph in set(old)|set(new):
        aa=old.get(glyph,[]);bb=new.get(glyph,[]);assert len(aa)==len(bb)
        for x,y in zip(aa,bb):
            if x!=y:
                assert x[:2]==y[:2] and 'uni05B3' in [glyph,*x[0],*x[1]]
                delta.append(dict(glyph=glyph,before=x,after=y))
    assert delta
    count=result['export']['existing_lookup_count']
    assert all(xml(a,a['GPOS'].table.LookupList.Lookup[i])==xml(b,b['GPOS'].table.LookupList.Lookup[i]) for i in range(count))
    for tag in a.reader.keys():
        if tag not in ('GPOS','head'):assert a.reader[tag]==b.reader[tag]
    aliases={cp for tab in a['cmap'].tables if tab.isUnicode() for cp,n in tab.cmap.items() if n=='uni05B3'}
    assert aliases=={0x05b3}
    # Every GSUB production of B3 already requires B3 as an input; neither
    # ligation with CGJ/dotted circle nor spacing substitution creates it.
    productions=[]
    for k,l in enumerate(a['GSUB'].table.LookupList.Lookup):
        for e in l.SubTable:
            st=getattr(e,'ExtSubTable',e)
            for source,dest in getattr(st,'mapping',{}).items():
                if 'uni05B3' in (dest if isinstance(dest,list) else [dest]):
                    assert source=='uni05B3';productions.append(k)
            for source,dest in getattr(st,'alternates',{}).items():
                if 'uni05B3' in dest:assert source=='uni05B3';productions.append(k)
            for source,dest in getattr(st,'ligatures',{}).items():
                for lig in dest:
                    if lig.LigGlyph=='uni05B3':assert 'uni05B3' in [source,*lig.Component];productions.append(k)
            if hasattr(st,'Substitute'):
                for source,dest in zip(st.Coverage.glyphs,st.Substitute):
                    if dest=='uni05B3':assert source=='uni05B3';productions.append(k)
    dump(OUT/'boundary-proof.json',dict(reference_sha256=sha(DEST),font_sha256=sha(CANDIDATE),compiled_delta=delta,
        cmap_aliases=['U+05B3'],gsub_cannot_generate_required_point_without_it=productions,
        necessary_condition='Raw or NFD input contains U+05B3; every other run is unaffected by the compiled delta.'))
    print('BOUNDARY CANDIDATE',sha(CANDIDATE),'changed rules',len(delta),flush=True)

def certify(scope,shard=0):
    p=read(OUT/'boundary-proof.json');assert sha(DEST)==p['reference_sha256'] and sha(CANDIDATE)==p['font_sha256']
    a,b=font(DEST),font(CANDIDATE);v.oldcheck.DEST=CANDIDATE;c=Check();start=time.time()
    if scope=='sefaria':
        prefix=f'sefaria-{shard}';ref=read(OUT/f'{prefix}-complete.json');db=sqlite3.connect(DB.as_uri()+'?mode=ro',uri=True)
        rs=(dict(id=i,text=t,count=n) for i,t,n in db.execute('select id,text,count from runs where id % 3=? order by id',(shard,)))
        payload={k:{r['id']:r for r in rows(OUT/f'{prefix}-{k}.jsonl')} for k in ['collisions','raster','regressions','changed','normalization']}
    else:
        prefix=scope;ref=read(OUT/f'{scope}-validation.json');rs=all_records(scope)
    assert ref['font_sha256']==p['reference_sha256']
    stats=Counter();differences=[];errors=[]
    for r in rs:
        t=r['text'];nf=ud.normalize('NFD',t);stats['runs']+=1
        if '\u05b3' not in t and '\u05b3' not in nf:stats['statically_unaffected']+=1;continue
        stats['reshaped_raw_nfd']+=1;aa,bb=shape(a,t),shape(b,t);an,bn=shape(a,nf),shape(b,nf)
        if aa==bb and an==bn:continue
        out=c.inspect(t);differences.append(dict(**r,**out))
        # This correction restores an existing clear fragment; any complete
        # changed source must stay free of contacts and identity changes.
        if any(out[k] for k in ['collisions','raster','identity']):errors.append(dict(**r,**out))
        if stream_geom(bb)!=stream_geom(bn):errors.append(dict(**r,reason='NFD_difference'))
        if scope=='sefaria':
            for kind in ['collisions','raster','regressions','normalization']:payload[kind].pop(r['id'],None)
            prior_moved=payload['changed'].get(r['id'],{}).get('moved_glyphs',0)
            ref['statistics']['moved_glyphs']+=out['moved_glyphs']-prior_moved
            if out['moved_glyphs']:payload['changed'][r['id']]=dict(**r,moved_glyphs=out['moved_glyphs'])
            else:payload['changed'].pop(r['id'],None)
    assert not errors,(scope,errors[:1]);assert stats['runs']==ref['statistics']['runs']
    cert=dict(**p,scope=prefix,statistics=stats,changed_complete_runs=len(differences),failures=errors,seconds=round(time.time()-start,1))
    dest=OUT/'bounded-validation';dest.mkdir(exist_ok=True);SNAP.mkdir(exist_ok=True)
    name=f'{prefix}-complete.json' if scope=='sefaria' else f'{prefix}-validation.json'
    shutil.copy2(OUT/name,SNAP/name);cert['reference_report_sha256']=sha(SNAP/name)
    dump(dest/f'{prefix}-certification.json',cert)
    if scope=='sefaria':
        ref['statistics']['changed_runs']=len(payload['changed']);ref['statistics']['identical_runs']=stats['runs']-len(payload['changed'])
        ref['statistics']['collision_runs']=len(payload['collisions']);ref['statistics']['collision_pairs']=sum(len(r['collisions']) for r in payload['collisions'].values())
        ref['statistics']['raster_runs']=len(payload['raster'])
        for kind,data in payload.items():
            shutil.copy2(OUT/f'{prefix}-{kind}.jsonl',SNAP/f'{prefix}-{kind}.jsonl')
            with (dest/f'{prefix}-{kind}.jsonl').open('w',encoding='utf8') as f:
                for _,r in sorted(data.items()):f.write(json.dumps(r,ensure_ascii=False)+'\n')
    else:assert not differences,'Old corpora should be unchanged by this optional boundary veto.'
    ref['font_sha256']=p['font_sha256'];ref['boundary_certification']=cert;ref['tables']=v.tables();dump(dest/name,ref)
    print('BOUNDARY CERTIFIED',prefix,dict(stats),'changed',len(differences),flush=True)

def promote():
    p=read(OUT/'boundary-proof.json');assert sha(DEST)==p['reference_sha256']
    for prefix in ['sefaria-0','sefaria-1','sefaria-2','merged','bibles','dictionaries','maagarim']:
        cert=read(OUT/'bounded-validation'/f'{prefix}-certification.json');assert not cert['failures'] and cert['font_sha256']==sha(CANDIDATE)
    shutil.copy2(DEST,SNAP/'font.ttf');shutil.copy2(OUT/'build.json',SNAP/'build.json')
    shutil.copy2(CANDIDATE,DEST);shutil.copy2(OUT/'bounded-build.json',OUT/'build.json');shutil.copy2(OUT/'bounded-optical-solutions.json',OUT/'optical-solutions.json')
    for f in (OUT/'bounded-validation').iterdir():shutil.copy2(f,OUT/f.name)
    print('PROMOTED',sha(DEST),flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('action',choices=['prepare','sefaria','prior','promote']);p.add_argument('--shard',type=int,default=0);a=p.parse_args()
    if a.action=='prepare':prepare()
    elif a.action=='promote':promote()
    elif a.action=='sefaria':certify('sefaria',a.shard)
    else:
        for scope in ['merged','bibles','dictionaries','maagarim']:certify(scope)
