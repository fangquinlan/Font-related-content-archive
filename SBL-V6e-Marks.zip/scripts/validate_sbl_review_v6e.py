"""Exhaustive input replay with exact, hash-checked V6d geometry reuse."""
from collections import Counter
import argparse,json,sqlite3,time,unicodedata as ud
import validate_sbl_sefaria_v6d as oldcheck
from build_sbl_review_v6e import BASE,DEST,OUT,PRIOR,read,rows
from audit_maagarim_sbl import ROOT,ComponentShaper,dump,locate
from audit_sbl_merged_v6b import nearby,pairkey,RasterOracle,SIZES,PHASES
from audit_dictionaries_v6b import layout_issues
from certify_sbl_v6c_final import font,shape
from validate_sbl_merged_v6c import all_records,source_path
from validate_v53 import conventions
from dictionary_corpus_v6b import sha

DB=ROOT/'data/sefaria-v6c/runs.sqlite3'
oldcheck.BASE=BASE;oldcheck.DEST=DEST
tables=oldcheck.tables;stream_geom=oldcheck.stream_geom;key=oldcheck.key

def baseline(kind):
    out={}
    for n in range(3):out.update({r['id']:r for r in rows(PRIOR/f'sefaria-{n}-{kind}.jsonl')})
    return out

class Check(oldcheck.Check):
    def __init__(self,phases=PHASES):
        super().__init__(phases)
        self.layers=[]
        for r in read(OUT/'build.json')['desired']:
            ds={int(i):xy[1] for i,xy in r['changes'].items() if xy[1]<0 and self.old.shape(r['text'])[int(i)]['box'][3]<0}
            if ds:self.layers.append((tuple(g['name'] for g in self.old.shape(r['text'])),ds))
    def inspect(self,t,check_layout=False):
        result=super().inspect(t,check_layout)
        aa,bb=self.old.shape(t),self.s.shape(t);identity=[];allowed={};names=tuple(g['name'] for g in aa)
        for needle,ds in self.layers:
            for k in range(len(names)-len(needle)+1):
                if names[k:k+len(needle)]==needle:
                    for i,dy in ds.items():allowed.setdefault(k+i,set()).add(dy)
        for i,(a,b) in enumerate(zip(aa,bb)):
            if (a['name'],a['cl'],a['advance'])!=(b['name'],b['cl'],b['advance']):identity.append('identity_or_advance')
            dx,dy=b['x']-a['x'],b['y']-a['y']
            if not a['mark'] and (dx or dy):identity.append('base_position')
            if a['mark'] and a['box'] and a['y']+a['box'][3]<0 and dy and dy not in allowed.get(i,set()):identity.append('unlisted_lower_layer')
        if len(aa)!=len(bb):identity.append('glyph_count')
        result['identity']=sorted(set(identity));return result

def focused():
    start=time.time();c=Check([p/64 for p in range(64)]);cases=read(OUT/'build.json')['desired'];errors=[]
    for n,r in enumerate(cases,1):
        out=c.inspect(r['text'],True)
        if any(out[k] for k in ('collisions','raster','identity','layout')):errors.append(dict(text=r['text'],**out))
        if n%100==0:print('FOCUS',n,len(cases),'failures',len(errors),flush=True)
    refs=[r for r in rows(PRIOR/'residual-pairs.jsonl') if r['classification']=='review']
    full={r['run_id']:r['text'] for r in refs};left=[];added=[]
    for rid,t in full.items():
        before=c.old.mark_collisions(c.old.expand(c.old.shape(t)))
        after=c.s.mark_collisions(c.s.expand(c.s.shape(t)))
        oldkeys={key(h) for h in before};newkeys={key(h) for h in after}
        left.extend(r['key'] for r in refs if r['run_id']==rid and key(r['collision']) in newkeys)
        added.extend(dict(run_id=rid,collision=h) for h in after if key(h) not in oldkeys)
    conv=conventions(c.s)
    result=dict(font_sha256=sha(DEST),fragments=len(cases),fragment_failures=errors,
        full_required_runs=len(full),required_pairs=len(refs),unresolved_required_keys=left,new_vector_pairs=added,
        conventions=dict(checks=len(conv),failures=[r for r in conv if not r['passed']]),tables=tables(),
        raster=dict(sizes=SIZES,phases=c.phases,new_states=c.states,alpha_threshold='both >153/255'),seconds=round(time.time()-start,1))
    dump(OUT/'focused-validation.json',result)
    print('FOCUSED',len(cases),'failures',len(errors),'remaining',len(left),'new',len(added),flush=True)

def prior(scope):
    started=time.time();a,b=font(BASE),font(DEST);fontsha=sha(DEST)
    ref=read(PRIOR/f'{scope}-validation.json');assert ref['font_sha256']==sha(BASE) and not ref['failures']
    src=source_path(scope);srcsha=sha(src);assert ref['source_sha256']==srcsha
    c=Check();counts=Counter();errors=[];changed=[];table=tables()
    for n,r in enumerate(all_records(scope),1):
        t=r['text'];nf=ud.normalize('NFD',t)
        aa,bb=shape(a,t),shape(b,t);an,bn=shape(a,nf),shape(b,nf)
        counts['runs']+=1;counts['occurrences']+=r.get('count',1)
        if stream_geom(bb)!=stream_geom(bn):errors.append(dict(**r,reason='nfd_geometry'))
        if aa==bb and an==bn:counts['identical_runs']+=1
        else:
            counts['changed_runs']+=1;out=c.inspect(t,True);counts['moved_glyphs']+=out['moved_glyphs']
            if any(out[k] for k in ('collisions','raster','identity','layout')):errors.append(dict(**r,**out))
            changed.append(dict(**r,moved_glyphs=out['moved_glyphs']))
        if n%10000==0:print('PRIOR',scope,n,'changed',counts['changed_runs'],'errors',len(errors),'seconds',round(time.time()-started),flush=True)
    assert counts['runs']==ref['statistics']['runs'] and sha(DEST)==fontsha
    dump(OUT/f'{scope}-validation.json',dict(font_sha256=fontsha,parent_sha256=sha(BASE),source_sha256=srcsha,
        statistics=counts,failures=errors,changed=changed,tables=table,
        reference=dict(path=str(PRIOR/f'{scope}-validation.json'),sha256=sha(PRIOR/f'{scope}-validation.json'),
            method='All raw/NFD streams reshaped. Reuse only for exact streams and unchanged outlines/metrics/hinting.'),
        raster=dict(sizes=SIZES,phases=PHASES,new_states=c.states),seconds=round(time.time()-started,1)))
    print('DONE',scope,dict(counts),'errors',len(errors),flush=True)

def sefaria(shard=0,workers=3,quick=False):
    start=time.time();fontsha=sha(DEST);a,b=font(BASE),font(DEST);c=Check();table=tables()
    oldhits=baseline('collisions');oldpixels=baseline('raster');oldnorm=baseline('normalization')
    for n in range(3):assert read(PRIOR/f'sefaria-{n}-complete.json')['font_sha256']==sha(BASE)
    selected=set(oldhits)|set(oldpixels);conn=sqlite3.connect(DB.as_uri()+'?mode=ro',uri=True)
    prefix='quick' if quick else f'sefaria-{shard}';checkpoint=OUT/f'{prefix}-progress.json';last=0;stats=Counter()
    if checkpoint.exists():
        old=read(checkpoint)
        if old['font_sha256']==fontsha and old['workers']==workers:last=old['last_id'];stats.update(old['statistics'])
    names=['collisions','raster','regressions','changed','normalization'];fs={k:(OUT/f'{prefix}-{k}.jsonl').open('a' if last else 'w',encoding='utf8') for k in names}
    def write(k,obj):fs[k].write(json.dumps(obj,ensure_ascii=False)+'\n')
    def save():
        for f in fs.values():f.flush()
        dump(checkpoint,dict(font_sha256=fontsha,workers=workers,shard=shard,last_id=last,statistics=stats,seconds=round(time.time()-start,1)))
    while True:
        got=conn.execute('select id,text,count from runs where id>? and id % ?=? order by id limit 500',(last,workers,shard)).fetchall()
        if not got:break
        for rid,t,count in got:
            last=rid
            if quick and rid not in selected:continue
            nf=ud.normalize('NFD',t);aa,bb=shape(a,t),shape(b,t);an,bn=shape(a,nf),shape(b,nf)
            stats['runs']+=1;stats['occurrences']+=count;record=dict(id=rid,text=t,count=count)
            if stream_geom(bb)!=stream_geom(bn):
                stats['raw_nfd_different_runs']+=1;write('normalization',record)
                if rid not in oldnorm:write('regressions',dict(**record,reason='new_raw_nfd_difference'))
            if aa==bb and an==bn:
                stats['identical_runs']+=1;hits=oldhits.get(rid,{}).get('collisions',[]);pixels=oldpixels.get(rid,{}).get('pairs',[])
            else:
                stats['changed_runs']+=1;out=c.inspect(t);hits=out['collisions'];pixels=out['raster'];stats['moved_glyphs']+=out['moved_glyphs']
                write('changed',dict(**record,moved_glyphs=out['moved_glyphs']))
                oldkeys={key(h):h for h in oldhits.get(rid,{}).get('collisions',[])}
                added=[h for h in hits if key(h) not in oldkeys];worse=[h for h in hits if key(h) in oldkeys and h['area']>oldkeys[key(h)]['area']+.5]
                oldp={(tuple(p['key'][:2]),tuple(p['clusters'])) for p in oldpixels.get(rid,{}).get('pairs',[])}
                extrap=[p for p in pixels if (tuple(p['key'][:2]),tuple(p['clusters'])) not in oldp]
                if added or worse or extrap or out['identity']:write('regressions',dict(**record,new_pairs=added,worsened_pairs=worse,new_raster_pairs=extrap,identity=out['identity']))
                if stream_geom(bb)!=stream_geom(bn) and an!=bn:
                    nout=c.inspect(nf)
                    if nout['collisions'] or nout['raster'] or nout['identity']:write('regressions',dict(**record,reason='changed_NFD_failure',nfd=nout))
            if hits:stats['collision_runs']+=1;stats['collision_pairs']+=len(hits);write('collisions',dict(**record,collisions=hits))
            if pixels:stats['raster_runs']+=1;write('raster',dict(**record,pairs=pixels))
            if stats['runs']%10000==0:print('SEFARIA',prefix,stats['runs'],'changed',stats['changed_runs'],'seconds',round(time.time()-start),flush=True);save()
        save()
    for f in fs.values():f.close()
    assert sha(DEST)==fontsha
    dump(OUT/f'{prefix}-complete.json',dict(font_sha256=fontsha,parent_sha256=sha(BASE),workers=workers,statistics=stats,tables=table,
        reference_report_sha256=[sha(PRIOR/f'sefaria-{n}-complete.json') for n in range(3)],
        database_sha256=read(ROOT/'data/sefaria-v6c/manifest.json').get('database_sha256'),
        raster=dict(sizes=SIZES,phases=PHASES,new_states=c.states,alpha_threshold='both >153/255'),seconds=round(time.time()-start,1)))
    print('DONE',prefix,dict(stats),flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('scope',choices=['focused','quick','sefaria','merged','bibles','dictionaries','maagarim','prior'])
    p.add_argument('--shard',type=int,default=0);p.add_argument('--workers',type=int,default=3);args=p.parse_args()
    if args.scope=='focused':focused()
    elif args.scope in ('quick','sefaria'):sefaria(args.shard,1 if args.scope=='quick' else args.workers,args.scope=='quick')
    elif args.scope=='prior':
        for scope in ['merged','bibles','dictionaries','maagarim']:prior(scope)
        import regression_sbl_dictionaries_v6b as g
        g.PARENT=BASE;g.DEST=DEST;g.REPORT=OUT;g.main()
    else:prior(args.scope)
