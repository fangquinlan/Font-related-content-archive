"""Read-only, full-text SBL V6 audit of the supplied Maagarim JSONL.

Keep text, editorial punctuation, whitespace, and mark order intact. Each
original line is a shaping run, including word boundaries. Composite Hebrew
base glyphs are expanded when they contain mark components, so a shin dot or
dagesh absorbed by GSUB is not silently exempted from the outline test.
"""
from collections import Counter
from pathlib import Path
import argparse
import bisect
import hashlib
import json
import re
import time
import unicodedata as ud

from hebrew_collision_v5 import Shaper

ROOT = Path(__file__).resolve().parents[1]
SOURCE = Path(r'E:\Bible\maagarim\maagarim_works.jsonl')
FONT = ROOT / 'output/v6/SBL_BLit-v6.ttf'
OUT = ROOT / 'reports/sbl-v6-maagarim'
MARK = re.compile('[\u0591-\u05bd\u05bf\u05c1\u05c2\u05c4\u05c5\u05c7]')
TOKEN = re.compile(r'\S+')


def dump(path, obj):
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')


class ComponentShaper(Shaper):
    def __init__(self, path):
        super().__init__(path)
        self.parts = {}
        self.near_results = {}

    def near(self, a, b, margin=16):
        # Translating both outlines equally cannot change their clearance.
        # Reuse exact pair tests across words during constrained mark fitting.
        key=(a['name'],b['name'],round(b['x']-a['x'],4),round(b['y']-a['y'],4),margin)
        if key not in self.near_results:
            if len(self.near_results)>250000:self.near_results.clear()
            self.near_results[key]=super().near(a,b,margin)
        return self.near_results[key]

    def components(self, name):
        if name not in self.parts:
            g = self.tt['glyf'][name]
            parts = [(name, 0, 0, name in self.marks)]
            if g.isComposite() and name not in self.marks:
                leaves = []
                for c in g.components:
                    cn, matrix = c.getComponentInfo()
                    a, b, c, d, dx, dy = matrix
                    # All relevant SBL mark composites use translation only.
                    children = self.components(cn)
                    if (a, b, c, d) != (1, 0, 0, 1):
                        assert not any(p[3] for p in children), (name, matrix)
                        leaves = []
                        break
                    leaves.extend((n, x+dx, y+dy, m) for n, x, y, m in children)
                if any(p[3] for p in leaves):
                    parts = leaves
            self.parts[name] = parts
        return self.parts[name]

    def expand(self, glyphs):
        parts = []
        for i, g in enumerate(glyphs):
            for n, dx, dy, mark in self.components(g['name']):
                parts.append(dict(g, name=n, x=g['x']+dx, y=g['y']+dy,
                                  box=self.geometry(n), mark=mark,
                                  parent=g['name'], glyph_index=i))
        return parts

    def mark_collisions(self, glyphs):
        boxes = []
        out = []
        for i, g in enumerate(glyphs):
            if g['box']:
                x0, y0, x1, y1 = g['box']
                boxes.append((x0+g['x'], y0+g['y'], x1+g['x'], y1+g['y'], i))
        boxes.sort()
        for k, a in enumerate(boxes):
            for j in range(k+1, len(boxes)):
                b = boxes[j]
                if b[0] >= a[2]:
                    break
                if b[1] >= a[3] or a[1] >= b[3]:
                    continue
                i1, i2 = sorted((a[4], b[4]))
                u, v = glyphs[i1], glyphs[i2]
                if not (u['mark'] or v['mark']):
                    continue
                area = self.area(u, v)
                if area > .5:
                    out.append(dict(i=i1, j=i2, area=area,
                                    names=[u['name'], v['name']],
                                    parents=[u['parent'], v['parent']],
                                    clusters=[u['cl'], v['cl']],
                                    delta=[v['x']-u['x'], v['y']-u['y']],
                                    same_cluster=u['cl'] == v['cl'],
                                    same_glyph=u['glyph_index'] == v['glyph_index'],
                                    kind='mark-mark' if u['mark'] and v['mark'] else 'mark-base'))
        return out


def signature(gs):
    return [(g['name'], g['x'], g['y'], g['advance']) for g in gs]


def locate(text, collisions):
    ts = list(TOKEN.finditer(text))
    starts = [m.start() for m in ts]
    for c in collisions:
        ix = [bisect.bisect_right(starts, cl)-1 for cl in c['clusters']]
        if any(i < 0 for i in ix):
            c['fragment'] = text
            c['token_indices'] = ix
            continue
        lo, hi = min(ix), max(ix)
        c['fragment'] = text[ts[lo].start():ts[hi].end()]
        c['token_indices'] = ix
        c['cross_token'] = lo != hi


def scan():
    OUT.mkdir(parents=True, exist_ok=True)
    s = ComponentShaper(FONT)
    font_hash = hashlib.sha256(FONT.read_bytes()).hexdigest()
    stats, chars, tokens, categories, pairs = (Counter() for _ in range(5))
    positive_tokens = {}
    forms_different = []
    missing = []
    h = hashlib.sha256()
    started = time.time()
    with SOURCE.open('rb') as src, (OUT/'colliding-lines.jsonl').open('w', encoding='utf-8') as dst:
        for jsonl_no, raw in enumerate(src, 1):
            h.update(raw)
            d = json.loads(raw)
            text = d['text']
            assert isinstance(text, str)
            chars.update(text)
            stats['works'] += 1
            stats['characters'] += len(text)
            stats['linebreaks'] += text.count('\n')
            for t in TOKEN.finditer(text):
                stats['tokens'] += 1
                if MARK.search(t.group()):
                    tokens[t.group()] += 1
                    stats['pointed_token_occurrences'] += 1
            offset = 0
            for line_no, raw_line in enumerate(text.splitlines(keepends=True), 1):
                line = raw_line.rstrip('\r\n\v\f\x1c\x1d\x1e\x85\u2028\u2029')
                line_offset = offset
                offset += len(raw_line)
                stats['original_lines'] += 1
                if not MARK.search(line):
                    continue
                ref = dict(jsonl_line=jsonl_no, misyzira=d['misyzira'], title=d['title'],
                           text_line=line_no, text_offset=line_offset)
                stats['shaped_lines'] += 1
                stats['shaped_characters'] += len(line)
                stats['max_line_length'] = max(stats['max_line_length'], len(line))
                gs = s.shape(line)
                stats['shaped_glyphs'] += len(gs)
                if any(g['name'] == '.notdef' for g in gs):
                    missing.append(dict(**ref, text=line))
                expanded = s.expand(gs)
                stats['expanded_components'] += len(expanded)-len(gs)
                hits = s.mark_collisions(expanded)
                locate(line, hits)
                nfd = ud.normalize('NFD', line)
                if nfd != line:
                    stats['nfd_text_different_lines'] += 1
                    ng = s.shape(nfd)
                    if signature(ng) != signature(gs):
                        stats['nfd_geometry_different_lines'] += 1
                        nh = s.mark_collisions(s.expand(ng))
                        locate(nfd, nh)
                        forms_different.append(dict(**ref, text=line, nfd=nfd,
                                                    raw_collisions=hits, nfd_collisions=nh))
                    else:
                        stats['nfd_geometry_equal_lines'] += 1
                else:
                    stats['nfd_already_normalized_lines'] += 1
                if hits:
                    stats['colliding_lines'] += 1
                    stats['collision_pairs'] += len(hits)
                    per_token = {}
                    for c in hits:
                        categories[(c['kind'], c['same_cluster'], c['same_glyph'], c.get('cross_token', False))] += 1
                        pairs[' / '.join(sorted(c['names']))] += 1
                        frag = c['fragment']
                        entry = positive_tokens.setdefault(frag, dict(text=frag, collision_instances=0,
                            colliding_occurrences=0, max_area=0, examples=[], pair_types=Counter()))
                        entry['collision_instances'] += 1
                        entry['max_area'] = max(entry['max_area'], c['area'])
                        entry['pair_types'][' / '.join(sorted(c['names']))] += 1
                        per_token.setdefault(frag, set()).add(tuple(sorted(c['token_indices'])))
                        if len(entry['examples']) < 2 and not any(x['misyzira'] == ref['misyzira'] and x['text_line'] == line_no for x in entry['examples']):
                            entry['examples'].append(dict(**ref, line=line, collision=c))
                    for frag, occurrences in per_token.items():
                        positive_tokens[frag]['colliding_occurrences'] += len(occurrences)
                    dst.write(json.dumps(dict(**ref, text=line, collisions=hits), ensure_ascii=False)+'\n')
                if stats['shaped_lines'] % 5000 == 0:
                    print('SCAN', json.dumps(dict(works=stats['works'], lines=stats['shaped_lines'],
                          colliding_lines=stats['colliding_lines'], fragments=len(positive_tokens),
                          cached_pairs=len(s.cache), seconds=round(time.time()-started, 1))), flush=True)
    # Assert that the selector covers every combining character in this corpus.
    combining = {c:n for c,n in chars.items() if ud.category(c).startswith('M')}
    assert all(MARK.fullmatch(c) for c in combining), combining
    assert not any(0xfb1d <= ord(c) <= 0xfb4f for c in chars), 'Unscanned Hebrew presentation form'
    rows = sorted(positive_tokens.values(), key=lambda x:(-x['colliding_occurrences'], -x['max_area'], x['text']))
    for r in rows:
        r['corpus_token_occurrences'] = tokens.get(r['text'], 0)
    dump(OUT/'colliding-fragments.json', rows)
    dump(OUT/'normalization-differences.json', forms_different)
    dump(OUT/'missing-glyph-lines.json', missing)
    dump(OUT/'pointed-token-counts.json', tokens)
    result = dict(source=str(SOURCE), source_sha256=h.hexdigest(), source_bytes=SOURCE.stat().st_size,
                  font=str(FONT), font_sha256=font_hash, upem=s.font.face.upem,
                  scope='Every original line in the JSONL text field containing a Hebrew combining mark; whitespace and editorial notation retained. HTML yezira is a duplicate representation and is not concatenated. Lines are independent RTL Hebrew shaping runs.',
                  vector_tolerance_native_area=.5, composite_mark_components_checked=True,
                  raw_and_nfd_checked=True, elapsed_seconds=round(time.time()-started, 2),
                  statistics=dict(stats), pointed_token_types=len(tokens),
                  colliding_fragment_types=len(rows), missing_glyph_lines=len(missing),
                  categories=[dict(kind=k[0], same_cluster=k[1], same_glyph=k[2], cross_token=k[3], count=v) for k,v in categories.items()],
                  pair_types=pairs,
                  combining_characters={f'U+{ord(c):04X}':dict(name=ud.name(c), count=n) for c,n in combining.items()},
                  controls={f'U+{ord(c):04X}':n for c,n in chars.items() if ud.category(c)=='Cf'},
                  expanded_composite_glyphs={n:p for n,p in s.parts.items() if len(p)>1})
    assert hashlib.sha256(FONT.read_bytes()).hexdigest() == font_hash
    dump(OUT/'scan-summary.json', result)
    print('DONE', json.dumps({k:v for k,v in result.items() if k not in ('expanded_composite_glyphs','combining_characters')}, ensure_ascii=False), flush=True)


if __name__ == '__main__':
    scan()
