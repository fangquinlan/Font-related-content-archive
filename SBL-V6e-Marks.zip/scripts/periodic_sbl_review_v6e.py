"""Fit repeated pedagogical mark combinations without widening the text."""
from concurrent.futures import ProcessPoolExecutor,as_completed
import copy,unicodedata as ud
import build_sbl_review_v6e as b
from build_sbl_review_v6e import *

def job(r):
    s=b.s;period=sum(g['advance'] for g in s.shape(r['text']+' '));attempts=[]
    for levels in ([0,-512],[0,-512,-1024],[0,-512,-1024,-1536]):
        try:delta,detail=solve(s,r['text'],b.rasters,max_dx=1024,annotation_layers=levels,first_feasible=True,periodic_x=period)
        except TimeoutError as e:delta=None;detail=dict(reason=str(e))
        attempts.append(dict(levels=levels,detail=detail))
        if delta is not None:
            return dict(text=r['text'],names=r['names'],changes=delta,period_native=period,attempts=attempts)
    return dict(text=r['text'],changes=None,attempts=attempts)

def main():
    data=read(OUT/'solutions.json');wanted=[r for r in data['rows'] if r['details'].get('method')=='explicit_overfull_annotation_levels'
        and r['text'][0]=='ו' and all(ud.category(c).startswith('M') for c in r['text'][1:])]
    cache=OUT/'periodic-solutions.json';saved=read(cache) if cache.exists() else []
    done={r['text']:r for r in saved if r['changes'] is not None}
    with ProcessPoolExecutor(max_workers=3,initializer=b.init) as pool:
        fs=[pool.submit(job,r) for r in wanted if r['text'] not in done]
        for f in as_completed(fs):
            r=f.result();done[r['text']]=r;dump(cache,list(done.values()));print('PERIODIC',repr(r['text']),r['changes'],flush=True)
    assert all(r['changes'] is not None for r in done.values())
    s=ComponentShaper(BASE)
    for filename in ['solutions.json','optical-solutions.json']:
        result=read(OUT/filename)
        for r in result['rows']:
            gs=s.shape(r['text']);names=[g['name'] for g in gs];changes={int(i):v for i,v in r['changes'].items()};matched=[]
            for sub in done.values():
                needle=sub['names'];expected={int(i):v for i,v in sub['changes'].items()}
                for k in range(len(names)-len(needle)+1):
                    if names[k:k+len(needle)]!=needle:continue
                    for i in range(len(needle)):
                        if gs[k+i]['mark']:changes[k+i]=expected.get(i,(0,0))
                    matched.append(sub['text'])
            if matched:
                r['changes']=changes;r['periodic_patterns']=matched
                r['optical']=dict(applied=False,reason='periodic annotation clearance takes precedence',previous=r.get('optical'))
                r['ink_bounds']=[min(g['y']+changes.get(i,(0,0))[1]+g['box'][1] for i,g in enumerate(gs) if g['box']),
                                 max(g['y']+changes.get(i,(0,0))[1]+g['box'][3] for i,g in enumerate(gs) if g['box'])]
        dump(OUT/filename,result)
    result=b.compile_font(sorted(read(OUT/'optical-solutions.json')['rows'],key=lambda r:r['text']));dump(OUT/'build.json',result)
    print('BUILT',sha(DEST),result['export'],flush=True)
if __name__=='__main__':main()
