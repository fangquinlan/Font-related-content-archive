# Zeph V6a：附标定位与两组字对间距修订

本次在既有 `Ῐ̓ησοῦ` 大写附标修订之上，修复 `ἔἶναι`、`ἕἶναι` 的附标擦碰。家族名称与文件名继续使用 **ZephText Optical V6a** / v6a；Regular／Italic 内部版本增至 6.202，Bold／Bold Italic 保持 6.201 且文件字节完全相同。沿用 V6 的 BD 字距模型与无损压缩结果。

## 2026-09-27：两组相邻附标修订

只给 `ἔἶ`、`ἕἶ` 这两个精确字形对增加间距：Regular 各 +25/1000 em，Italic 各 +27/1000 em。24 px 正文下分别约增加 0.60 px、0.65 px，使相邻轮廓间达到本次选用的 16 字体单位间隙。Bold／Bold Italic 原本在这两组字对上没有碰撞。这里没有扩大到整个 epsilon／iota 类。

每款受影响字体追加一个包含两个精确记录的 PairPos lookup，GPOS 仅比此前 V6a 增加 **40 字节**；所有既有 lookup、轮廓、字宽、hinting 和附标规则保持。新规则挂在希腊文 kern 功能，正常启用字距时生效；关闭 kern 将回到此前的字距。

Regular 和 Italic 各对 ngram 原始词库的 **2,584,433 个词形**做前后定位和新字体 NFD 等价对照。仅 `ἔἶναι`、`ἕἶναι`、`ἔἶχε`、`ἕἶδος` 四个词变化，后两词共享相同字对；其余 **2,584,429 个词形**定位逐项相同。原文字符不变，目标词轮廓零交集；14／18／20／22／24／32／46／64 ppem 四相位栅格检查也通过。此前其他附标碰撞均保持原位置；本轮不改变用户已接受的另外五种碰撞关系。修订后全词库附标碰撞词形为 Regular／Italic 各 38，Bold／Bold Italic 仍各 25。

浏览器新旧对照共 1232 项检查通过，目标宽度增量符合设计，非目标示例像素保持，NFD 显示相同。详细证据见 epsilon-iota-validation.json 与 epsilon-iota-browser-validation.json；[新旧对照页](http://127.0.0.1:8765/proof/v6a-epsilon-iota.html)。上一版保存在 output/history/v6a-before-epsilon-iota，原先 42 词审查页面已固定使用该存档，避免历史碰撞数据与新字体混用。

## 大写长短音符与气符：原有修订

[Wiktionary 原文](https://en.wiktionary.org/wiki/%E1%BC%B8%CE%B7%CF%83%CE%BF%E1%BF%A6%CF%82#Ancient_Greek)实际使用 `U+1FD8 U+0313 U+03B7 U+03C3 U+03BF U+1FE6`。第一个字形是带短音符的大写 Ι，随后还有柔气符。旧 Zeph 的通用附标定位使柔气符进入大写 Ι 的笔画区域；单纯修改相邻字母的 kerning 不能处理这个簇内部的重叠。

修订沿用同一字体预合成大写字母 `Ἀ Ἁ Ἰ Ἱ Ὑ` 的气符位置：目标组合出现时，将大写字母适当右移并增加该簇的行进宽度，再把气符附着在左侧。短音符／长音符继续保留在字母上方。Regular 的目标词首增加 229/1000 em 的宽度；24 px 下全词约增加 5.50 px，这是给原先挤进字母的气符留空间。Bold 为 230/1000 em。

大写附标修订追加一个上下文 GPOS 入口及四个嵌套 lookup。嵌套定位不单独作为全局附标规则启用，避免只改变附标位置却漏掉留白的情况。该部分不增加字形或 kerning 字对；上文两组字对规则是后续的独立追加。原始文件、V6、盲测记录与矩阵共 82 个受保护文件哈希核验未变。

覆盖 Α／Ι 的短音符、长音符 × 柔气符、粗气符，以及 Υ 的短音符、长音符 × 粗气符，共 10 种先编码长短音符的组合；另处理 10 种先编码气符的组合。此修订没有给大写 Υ 发明柔气符规则。

[Unicode 17 第 7 章](https://www.unicode.org/versions/Unicode17.0.0/core-spec/chapter-7/)列明了希腊文使用的组合附标及其编码顺序。原文的 NFD 是 `Ι + U+0306 + U+0313 …`。短音符与柔气符的组合类别同为 230；`Ἰ + U+0306` 是另一种顺序，并不与原文规范等价。两种順序分别支持，未通过悄悄交换字符来修复显示。Unicode 用于核验字符语义与顺序；具体气符放在左侧的设计取自 Zeph 自身的预合成大写字形，不声称 Unicode 规定了这些锚点数值。

## 表体积

| 样式 | V6 GPOS 字节 | V6a GPOS 字节 | 增量 |
|---|---:|---:|---:|
| Regular | 30,030 | 30,540 | +510 |
| Italic | 29,706 | 30,210 | +504 |
| Bold | 86,282 | 86,764 | +482 |
| Bold Italic | 83,302 | 83,784 | +482 |

这是整个 GPOS 的实际编译大小，每款增加约 0.5 KB。这里没有重新拟合或改写 V6 已通过盲测的字距矩阵。

## 验证

- 每款 360 次重点 shaping：20 种组合、后续字母、目标词及变体，含 NFC／NFD、kern 开关及连字开关。字形序列与字符簇身份保持，正文基线保持，目标附标无缺失，逐字形轮廓交集为零。
- 每款 960 个词首、词中、括号、引号、空格边界探针，均为零轮廓碰撞。轮廓容差为 0.5 原生字体单位平方，包含同一字符簇内部的碰撞，不跳过附标。
- 每款 19,191 个现有测试词、5 个冻结段落和其他回归探针；NFC／NFD 共 39,068 次新旧 shaping 完全一致。四款合计 156,272 次。
- FreeType 按独立字形遮罩检查，14、18、20、22、24、32、46、64 ppem，四个水平相位，四款共 5,760 个样本，修订后深色遮罩重叠像素为零。启用 hinting，阈值为两字形各自像素覆盖率均大于 60%；抗锯齿浅边接近不算作深色重叠。
- Chrome 实际加载的 8 份新旧 Zeph 文件与 2 份 Brill 参照均经网络 SHA-256 校验。七个字号、四个起点相位：672 次普通文本新旧像素／宽度相同，560 次原文与 NFD 像素／宽度相同，112 次目标修订生效。浏览器 DPR 0.9375；Canvas 比较在其显式位图尺寸内进行，实际 DOM 另检查四种样式的 18／24 px 显示并查看截图。页面未使用合成粗体或合成斜体。

这项验证针对明确的组合和当前 HarfBuzz／FreeType／Chrome 环境。任意三层以上附标不是已解决范围：例如再加锐音符、重音符或插入下点的复杂序列仍可能有原有碰撞，详见 validation.json 的 out_of_scope_stack_diagnostics；这些诊断未出现新增或扩大碰撞。不把本次结果外推成所有希腊文附标、所有排版引擎均无碰撞。

## Brill 核验

目录中的 Brill 5.05 TIRO **Italic** 可复现原文与 NFD 的碰撞，轮廓相交面积约 63,600.7 原生单位平方（UPEM 4000）；另序 `Ἰ̆ησοῦ` 在本地样本上没有碰撞。Roman、Bold、Medium、Semibold 在目标词的同一几何检查中没有碰撞。Chrome 对照页也能复现 Italic 的问题。

这是具体样式与版本的差异，不代表所有 Brill 均损坏。Wiktionary 的词源标记虽然使用 i 元素，但当前页面计算样式为 normal，不能单凭该标签推断它调用了 Italic。本次只诊断 Brill，交付字体为四款 Zeph；Brill 原文件不变。

## 使用与复现

安装需要的 TTF，在应用中选择 **ZephText Optical V6a**，保留正常的 OpenType 附标定位与 kerning。网页可加载 fonts-v6a.css 并使用 zeph-v6a 类。大写附标修订由 mark 功能驱动，两组相邻附标修订由 kern 驱动。若已安装上一版，替换同名字体后重新启动使用字体的应用，避免旧缓存继续显示。

Zeph 的希腊字形本身具有倾斜风格，Regular／Italic 的关系沿用字体自身设计，未额外合成倾斜。旧 V6 字体和试读页面保留；GFS、SBL 延续 V6，本次没有安装系统字体。

在 E:\kerning 下依次运行 `.venv/Scripts/python.exe scripts/build_quantity_marks_v6a.py`、`scripts/validate_quantity_marks_v6a.py`、`scripts/build_quantity_proof_v6a.py`（每条均使用同一 Python）。另运行 validate_epsilon_iota_v6a.py --style Regular / Italic / Bold / "Bold Italic" 四个检查及 build_epsilon_iota_proof_v6a.py。启动本地 HTTP 服务器，分别执行两页的 quantityQA 或 epsilonQA 中 run()、hashes()，保存各自 browser-validation.json 后运行 scripts/deliver_quantity_marks_v6a.py。构建直接读取原 V6 文件，不重新训练模型。provenance.json 记录源码与依赖版本。
