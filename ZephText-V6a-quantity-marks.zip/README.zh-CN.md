ZephText Optical V6a

四款 TTF：Regular、Italic、Bold、Bold Italic。保留 Ῐ̓ησοῦ 大写附标修订，并修复 Regular／Italic 中 ἔἶναι、ἕἶναι 的相邻附标碰撞。只调整 ἔἶ、ἕἶ 两组字对；共享这些字对的 ἔἶχε、ἕἶδος 也受益。其他字对沿用上一版 V6a。

安装所需 TTF 后选择字体家族“ZephText Optical V6a”。浏览器可加载 fonts-v6a.css，使用 class="zeph-v6a"；样式设置为普通 CSS 的 normal/italic 与 400/700。保留 mark 与 kern 功能。若已经安装之前的同名字体，请替换后重新启动使用该字体的应用。Regular／Italic 内部版本 6.202；Bold／Bold Italic 仍为 6.201。

说明与测试边界见 REPORT.zh-CN.md，校验见 manifest.json、validation.json 与 browser-validation.json。原始版权和许可字段见 LICENSES.txt／LICENSES.json。

本包只包含四款 Zeph；GFS、SBL 继续使用已交付 V6。V6 原字体保留，未自动安装系统字体。
